var system = require('system');

function wrapError(error) {
    var errorStr = error;
    if (typeof error !== 'string') {
        try {
            errorStr = JSON.stringify(error);
        } catch (ex) {
            errorStr = 'PhantomJS "wrapError" error, can not stringify error object.';
        }
    }
    return '{{start}}' + errorStr;
}

function wrapWarning(error) {
    var errorStr = error;
    if (typeof error !== 'string') {
        try {
            errorStr = JSON.stringify(error);
        } catch (ex) {
            errorStr = 'PhantomJS "wrapWarning" error, can not stringify error object.';
        }
    }
    return '{{start}}[warn]' + errorStr;
}

function workarounds(widgets) {

    // This workaround we need to avoid phantom crash related with circular dependencies (indicator.indicatorInstance)
    // in widget properies. Here we iterate every widget and every widgets property and
    // trying to JSON stringlify it. If it can be stringified, then its ok. Otherwise,
    // this property contain some circular dependency and will throw phantom exception:
    // Error: incompatible type of argument(s) in call to call(); candidates were call(QVariantList)
    // So we handle this situation and remove this property from widget.
    // TODO: We need to add some logs for such cases.
    for (key in widgets) {
        for (key1 in widgets[key]) {
            try {
                JSON.stringify(widgets[key][key1]);
            } catch (e) {
                delete widgets[key][key1];
            }
        }
    }

    // Workaround for bug in phantom2 with ellipsis in block with right aligned text.
    // It doesn't take into account ellipsis (three dots after text node) when there right padding,
    // so we are adding few more pixels to right padding and removing few from left one. (weird phantom)
    $('.treemap-widget-content .label:not(.tm-hidden)').each(function () {
        if (this.offsetWidth < this.scrollWidth) {
            this.style.paddingLeft = '4px';
            this.style.paddingRight = '13px';
        }
    });

    widgets.forEach(function (widget) {
        if (widget.type === 'chart/boxplot') {
            var widgetElem = $('[widgetid=' + widget.oid + ']');

            if (widgetElem.length === 0) {
                var widgetElem = $('[widgetid-container=' + widget.oid + ']');
            }

            // Workaround for bug in phantom2 with fractional stroke-opacity.
            // It doesn't work properly and breakes coordinates for path,
            // so we change stroke opacity to 1
            var paths = widgetElem[0].getElementsByTagName('path');
            for (var i = paths.length - 1; i >= 0; i--) {
                changeOpacity(paths[i]);
            }
            var gElements = widgetElem[0].getElementsByTagName('g');
            for (var i = gElements.length - 1; i >= 0; i--) {
                changeOpacity(gElements[i]);
            }
        }
    });

    function changeOpacity(element) {
        var strokeOpacity = element.getAttribute('stroke-opacity');
        if (strokeOpacity != null && Number(strokeOpacity) == strokeOpacity && strokeOpacity % 1 !==
            0) { // if is float
            element.setAttribute('stroke-opacity', 1);
        }
    }
}

try {
    var
        page = require('webpage').create(),
        fs = require('fs'),

        url = system.args[1],
        outputFile = system.args[2],
        paperFormat = (system.args[3] || 'a4').toLowerCase(),
        paperOrientation = system.args[4],
        DPI = system.args[5],
        layout = system.args[6],
        width = parseInt(system.args[7]),
        height = parseInt(system.args[8]),
        resourceTimeout = parseInt(system.args[9]),
        token = system.args[10],
        customFilters = system.args[11] ? JSON.parse(system.args[11]) : [],
        showNarration = system.args[12] !== 'false',
        paperMargin = 10,

        mmToPx = function (mm) {
            return Math.floor(DPI * (mm / 25.4));
        },

        knownPapers = {
            /*         -----------------------------
                        name          width   height
                       -----------------------------  */
            'a0': [841, 1189],
            'a1': [594, 841],
            'a2': [420, 594],
            'a3': [297, 420],
            'a4': [210, 297],
            'a5': [148, 210],
            'a6': [105, 148],
            'a7': [74, 105],
            'a8': [52, 74],
            'a9': [37, 52],
            'b0': [1000, 1414],
            'b1': [707, 1000],
            'b2': [500, 707],
            'b3': [353, 500],
            'b4': [250, 353],
            'b5': [176, 250],
            'b6': [125, 176],
            'b7': [88, 125],
            'b8': [62, 88],
            'b9': [33, 62],
            'b10': [31, 44],
            'c5e': [163, 229],
            'us-common': [105, 241],
            'dle': [110, 220],
            'folio': [210, 330],
            'ledger': [431.8, 279.4],
            'tabloid': [279.4, 431.8],
            'letter': [215.9, 279.4],
            'legal': [215.9, 355.6],
            'executive': [190.5, 254]
        },

        // use A4 by default or if given format is unknown
        paper = knownPapers[paperFormat] || knownPapers['a4']
    ;
    if (paperOrientation == 'landscape') {
        paper.push(paper.shift());
    }
    if (!width) {
        page.paperSize = {
            format: paperFormat,
            orientation: paperOrientation,
            margin: paperMargin + 'mm'
        };
    }

    console.log('phantom started', system.args);

    page.viewportSize = {
        width: width ? width : mmToPx(paper[0] - (paperMargin * 2)),
        height: height ? height : 1 // we don't care about the viewport height as far as it brings us only problems
    };

    page.settings.resourceTimeout = resourceTimeout * 1000;
    page.settings.userAgent = 'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2125.111 Safari/537.36 phantom';

    page.customHeaders = {
        'X-Must-Store': 'yes',

        // Add the Bearer token header for every request to page or resource
        'Authorization': 'Bearer ' + token
    };

    page.onCallback = function (widgets) {
        try {
            if (widgets) {
                for (var i = 0; i < widgets.length; i++) {
                    if (widgets[i].$error) {
                        system.stderr.write(wrapWarning(widgets[i].$error));
                    }
                }
            }
        } catch (ex) {
            system.stderr.write(wrapWarning(ex.message));
        }

        setTimeout(function () {
                if (fs.exists(outputFile)) {
                    try {
                        fs.remove(outputFile);
                    } catch (ex) {
                        system.stderr.write(
                            wrapError('Error removing output file "' + outputFile + '"'));
                        phantom.exit(1);
                        return;
                    }
                }

                page.render(outputFile);
                phantom.exit(0);
            },
            1000
        ); // HACK wait for resources will be loaded, because last requested resources are svg
    };
    page.onError = function (msg) {
        console.log('error: ' + msg + ' ');
        system.stderr.write(wrapWarning(msg));
    };
    page.onConsoleMessage = function (msg, lineNum, sourceId) {
        console.log('CONSOLE: ' + msg + ' (from line #' + lineNum + ' in ' + sourceId + ')');
    };
    page.open(url, function (status) {
        console.log('page open', resourceTimeout, typeof resourceTimeout);
        if (resourceTimeout == NaN) {
            resourceTimeout = 60;
        }
        resourceTimeout = 60;

        var triesCount = (resourceTimeout * 1) / 10;
        var findPrism = function (tryIndex) {
            console.log('----------------------');
            console.log(page.injectJs('jquery-1.12.2.js'));

            var result = page.evaluate(
                function (layout, workarounds, resourceTimeout, customFilters, showNarration,
                          tryIndex, triesCount
                ) {
                    console.log('evaluate start', triesCount);
                    if (typeof resourceTimeout != 'number') {
                        resourceTimeout = 60;
                    }
                    resourceTimeout = 60;
                    var triesCount = parseInt(triesCount);

                    var nextTryIndex = tryIndex;
                    console.log('nextTryIndex', nextTryIndex, triesCount);
                    console.log('typeof($)', typeof ($));
                    if (window) {
                        console.log('window.prism', window.prism);
                        if (window.prism) {
                            //console.log('window.prism.$injector', window.prism.$injector);
                            if (window.prism.$injector) {
                                console.log('window.prism.$injector', window.prism.$injector);
                            }
                        }

                    }
                    var loadMore = (typeof ($) == 'undefined') || (window.prism === undefined) ||
                        (window.prism.$injector === undefined);
                    var tryAgain = loadMore && nextTryIndex < triesCount;
                    console.log('loadMore', loadMore);
                    console.log('tryAgain', tryAgain);

                    if (tryAgain) {

                    } else {
                        console.log('page start');
                        var startLogic = function () {

                        };
                        if (window.prism === undefined) {
                            console.log('timeout');
                            console.log(JSON.stringify(setTimeout));
                            console.log(JSON.stringify($timeout));
                            console.log('startLogic');
                            try {
                                setTimeout(function () {
                                    setTimeout(function () {
                                        //Your function here
                                        startLogic();
                                    }, 20);
                                }, 1);
                            } catch (e) {
                                console.log(e);
                            }

                        } else {
                            console.log('run, Hans!');
                            $(document).ready(function () {
                                console.log('domready');
                                // setup custom dashboard filters which overide user's filters
                                window.prism.externalFilters = customFilters;
                                window.prism.run([
                                    '$rootScope', function ($rootScope) {
                                        $rootScope.$on('dashboardloaded', function (event, args) {
                                            var dashboard = args.dashboard;
                                            dashboard.on('domready', function (event, args) {
                                                var widgets = args.widgets;
                                                if (dashboard.hasNarration() && showNarration) {
                                                    if (dashboard.hasLoadedNarration()) {
                                                        notifyAboutReady(widgets);
                                                    } else {
                                                        dashboard.on('narrationready', function () {
                                                            notifyAboutReady(widgets);
                                                        });
                                                    }
                                                } else {
                                                    notifyAboutReady(widgets);
                                                }
                                            });
                                        });
                                    }]);

                                if (layout == 'asis') {
                                    $('body').addClass('export-layout-as-is');
                                } else if (layout == 'feed') {
                                    $('body').addClass('export-layout-feed');
                                }
                            });

                        }

                        /*$(document).ready(function(){
                            console.log('dom ready');

                            startLogic.call(this);

                        });*/
                    }

                    function notifyAboutReady(widgets) {
                        try {
                            workarounds(widgets);
                        } catch (err) { /* ignore workarounds errors, if any */ }

                        // it seems like the rich text editor causes flickering on dashboard
                        // while rendering, so we wait 2 more seconds before we tell phantom
                        // to take the snapshot. see PRIS-13391 - PDF corrupted and missing data on charts
                        setTimeout(function () { window.callPhantom(widgets); }, 4000);
                    }

                    return !tryAgain ? window.prism : null;
                }, layout, workarounds, resourceTimeout, customFilters, showNarration, tryIndex,
                triesCount
            );

            return result;
        };

        if ((!page.injectJs('jquery-1.12.2.js')) || (status !== 'success')) {
            system.stderr.write(
                wrapError('https://support.sisense.com/entries/62547570-Error-exporting-to-PDF'));
            phantom.exit(1);
        } else {
            var step = 0;
            //var triesCount = resourceTimeout * 1000 / 10;
            var $prism = findPrism(step);
            step++;
            if (!$prism) {
                var prismInterval = setInterval(function () {

                    $prism = findPrism(step);
                    if ($prism) {
                        clearInterval(prismInterval);
                        console.log('found prism');
                    } else {
                        step++;
                    }

                    if (step > triesCount) {
                        clearInterval(prismInterval);
                    }

                }, 1000);
            }
            console.log($prism);
        }
    });
} catch (ex) {
    system.stderr.write(wrapError(ex.message));
    phantom.exit(1);
}
