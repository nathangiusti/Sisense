const rp = require('request-promise-native'),
    _ = require('lodash'),
    env_config = require('config'),
    geoErrors = require('./geo.errors'),
    logger = require('../../../common/logger').default('geo-service'),
    path = require('path');

const oldVersion = '5.1';
const newVersion = '6.0';

// city (city) - place
// state (adm) - region
// country (county) - country

class GeoService {
    constructor(request = rp, token = env_config.geo.mapbox_token) {
        this._request = request;
        this._access_token = token;
        this.isProxyMode = false;
    }

    init(config) {
        this.geoMongo = config.geoMongo;
        this.geoNotFoundMongo = config.geoNotFoundMongo;
        this.isProxyMode = config.isProxyMode;
    }

    /**
     * Performs geocoding of the given locations
     *
     * @param   {Object} locations
     * @param   {String} placetype
     * @returns {Promise}
     */
    getLocations(locations, placetype) {
        if (!locations) {
            logger.error('Locations parameter not found');
            throw new geoErrors.EmptyParams();
        }

        if (!(locations instanceof Array)) {
            logger.error('Locations parameter is not an array');
            throw new geoErrors.InvalidParams();
        }

        if (this.isProxyMode) {
            locations.forEach(location => {location.lookupKey = this._lookupKey(location);});
            return this._runLookups(locations, placetype).then(geoLocations => geoLocations);
        }

        let lookupKeys = this._getLookupKeys(locations);
        let unknownLookupKeys, foundLocationsInMongo, countRequestsToMapbox = 0;

        return this._findLocationsInMongo(lookupKeys, placetype)
            .then(foundLocations => {

                foundLocationsInMongo = foundLocations;
                let foundLookupKeys = this._getLookupKeys(foundLocations);
                unknownLookupKeys = _.difference(lookupKeys, foundLookupKeys);

                return this._getNotFoundLocations(unknownLookupKeys, placetype);
            })
            .then(notFoundLocations => {

                let finalLookups = this._getLookupsForRequest(unknownLookupKeys, locations,
                    notFoundLocations
                );
                countRequestsToMapbox = finalLookups.length;

                return this._runLookups(finalLookups, placetype);
            })
            .then(geoLocations => {
                this._saveLocationsInMongo(geoLocations).catch(err => {
                    logger.error('Saving locations in mongo error', err);
                });
                geoLocations = this._getLocationsWithCoordinates(geoLocations);
                return {
                    geoLocations: foundLocationsInMongo.concat(geoLocations),
                    countReqToMb: countRequestsToMapbox
                };
            });
    }

    /**
     * Returns area map boundaries for the given teriann type
     *
     * @param   {String} type
     * @returns {Promise}
     */
    getGeoJsonPath(type) {
        const
            SUPPORTED_TYPES = ['world', 'usa']
        ;

        if (!~SUPPORTED_TYPES.indexOf(type)) {
            logger.error('Locale type not found');
            throw new geoErrors.NotFound(type);
        }

        return path.resolve(__dirname, `../geoJson/${type}.json`);
    }

    _findLocationsInMongo(lookupKeys, placetype) {
        const mongoQuery = {
            $and: [
                { lookupKey: { $in: lookupKeys } },
                { placetype: placetype },
                { version: { $in: [oldVersion, newVersion] } }
            ]
        };
        return this.geoMongo.findAll(mongoQuery);
    }

    _getNotFoundLocations(unknownLookupKeys, placetype) {
        return this.geoNotFoundMongo.findAll({
            $and: [
                { lookupKey: { $in: unknownLookupKeys } },
                { placetype: placetype },
                { version: newVersion }
            ]
        });
    }

    _saveLocationsInMongo(geoLocations) {
        let countNotFoundItems = 0;
        let upsertPromises = geoLocations.map(location => {
            if (location && !location.err && location.latLng) {
                location.version = newVersion;

                if (location.lookupKey) {
                    // we use atomic operation 'upsert' instead of use logic like
                    // "if not found then insert" as far as it may potentially
                    // insert duplicates between "find" and "insert" ops in between by another process
                    return this.geoMongo.upsert(
                        {
                            lookupKey: location.lookupKey,
                            version: { $in: [oldVersion, newVersion] },
                            placetype: location.placetype
                        },
                        location
                    );
                }

            } else if (location && location.err && location.err.message === 'not found') {
                countNotFoundItems++;
                return this.geoNotFoundMongo.upsert(
                    {
                        lookupKey: location.lookupKey,
                        version: { $in: [oldVersion, newVersion] },
                        placetype: location.placetype
                    },

                    {
                        lookupKey: location.lookupKey,
                        version: newVersion, lastRequested: new Date,
                        placetype: location.placetype
                    }
                );
            }
        });

        logger.info('saving ' + countNotFoundItems + ' not found locations');

        return Promise.all(upsertPromises);
    }

    _getLookupsForRequest(unknownLookupKeys, locations, notFoundItems) {
        unknownLookupKeys = unknownLookupKeys || [];
        notFoundItems = notFoundItems || [];

        let locationHash = {};

        // run over each location and add it to the hash
        for (let i = 0; i < locations.length; i++) {
            let key = this._lookupKey(locations[i], locations);
            locationHash[key] = locations[i];
            locationHash[key].lookupKey = key;
        }

        let notFoundKeys = this._getLookupKeys(notFoundItems);

        let lookups =
            _.difference(unknownLookupKeys, notFoundKeys)
                .map(item => locationHash[item])
                .filter(item => !!item)
                .filter(item => this._isDefinedItem(item));

        return lookups;
    }

    _runLookups(lookups, placetype) {

        let reqPromises = lookups.map(lookup =>
            this._getLookupPromise(lookup, placetype)
        );

        logger.info('running ' + reqPromises.length + ' queries to Mapbox');

        return Promise.all(reqPromises).then(values => values)
            .catch(err => {
                logger.error('Mapbox api error - ' + err.message);
                throw new geoErrors.MapboxError(err.message);
            });
    }

    _getLookupPromise(lookup, placetype) {
        return new Promise((resolve, reject) => {
            const reqUrl = this._getReqUrl(lookup.lookupKey, placetype || lookup.placetype);
            this._request(reqUrl)
                .then(value => {
                    value = JSON.parse(value).features[0];
                    if (!value) {
                        throw new Error('not found');
                    }
                    let location = {
                        placetype: placetype || lookup.placetype, // lookup may contain placetype if the req comes from the old version
                        lookupKey: lookup.lookupKey,
                        name: lookup.name,
                        text: value.text,
                        place_name: value.place_name,
                        latLng: {
                            lat: value.center[1],
                            lng: value.center[0]
                        },
                        context: value.context,
                        err: null
                    };
                    resolve(location);
                }).catch(err => {

                if (err && err.message !== 'not found') {
                    reject(err);
                }

                //hide not found error for requests from old versions
                if (this.isProxyMode) {
                    err = null;
                }

                resolve({
                    lookupKey: lookup.lookupKey,
                    placetype: placetype || lookup.placetype,
                    name: lookup.name,
                    err: err
                });
            });
        });
    }

    _lookupKey(location, requestLocations) {
        if (requestLocations instanceof Array && requestLocations.length) {
            // backward-compatible mode with old geo-server
            // here we are taking into account that old geo-server does not respond
            // lookupKey, so we have to construct it, but taking into account
            // that it MUST be done over requested location item, not the something
            // we got in response
            let requestLocation = requestLocations.filter(loc =>
                loc.name.toLowerCase() == location.name.toLowerCase())[0];

            location = requestLocation || location;
        }

        let key = location.name;

        if (!key) {
            return null;
        }

        if (location.country) {
            key += (',' + location.country);
        }

        if (location.state) {
            key += (',' + location.state);
        }

        if (location.city) {
            key += (',' + location.city);
        }

        return key.toLowerCase();
    };

    _getLookupKeys(items) {
        return items.map(item => item.lookupKey || this._lookupKey(item, items)).filter(key => key);
    }

    _getReqUrl(lookupKey, placetype) {
        let types = 'place,region,country,postcode';

        if (placetype === 'city') {
            types = 'place';
        } else if (placetype === 'adm') {
            types = 'region';
        } else if (placetype === 'country') {
            types = 'country';
        }
        types = encodeURIComponent(types);
        lookupKey = encodeURIComponent(lookupKey.toString());
        return 'https://api.mapbox.com/geocoding/v5/mapbox.places/' +
            lookupKey + '.json?access_token=' + this._access_token +
            '&types=' + types + '&autocomplete=false&limit=1';
    }

    _isDefinedItem(item) {
        const locationName = item.name.toLowerCase().replace(/\\/g, '/').split(',')[0];

        return locationName.indexOf('n/a') === -1;
    }

    _getLocationsWithCoordinates(items) {
        return items.filter(item =>
            item && !item.err && item.latLng && item.latLng.lat
        );
    }
}

module.exports = GeoService;
