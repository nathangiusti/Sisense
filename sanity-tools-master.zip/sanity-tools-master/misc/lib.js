// General Info
var version = '3.0.0';

if (global._babelPolyfill) {
    throw new Error('only one instance of babel-polyfill is allowed');
}
global._babelPolyfill = true;