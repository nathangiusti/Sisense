/**
 * Created by yaroslav.korzh
 * Updated 09/02/2019
 */
// General Info
var version = '3.0.0';
var scriptName = 'Datasource replacer';

// Configuration
var showLogs = true;

var doCleanup = true;
if (typeof globalCleanup !== 'undefined') {
    // global cleanup
    // comment line below to use local cleanup flag
    doCleanup = globalCleanup;
}

var config = {
    cleanup: {
        doCleanup: doCleanup
    },
    logging: {
        showLogs: showLogs
    }
};

// Common Functions
var checkForHexRegExp = new RegExp('^[0-9a-fA-F]{24}$');
var prismWebDB = db.getSiblingDB('prismWebDB');
var prismConfig = db.getSiblingDB('prismConfig');

function getStatus(flag) {
    return flag ? 'enabled' : 'disabled';
}

function logger(msg) {
    if (showLogs) {
        print(msg);
    }
}

function getIssuesStatus(flag) {
    return flag ? 'fixed' : 'found';
}

// example of usage - collectStats('no_owner_dashboard', 1);
function collectStats(key, value) {
    if (typeof collectedStats !== 'undefined') {
        if (collectedStats[key]) {
            collectedStats[key] += value;
        } else {
            collectedStats[key] = value;
        }
    } else {
        collectedStats = {};
        collectedStats[key] = value;
    }
}

function printStats() {
    if (typeof globalRun == 'undefined') {
        logger(scriptName + ' statistics ' + ' © Sisense');
        logger('Total issues ' + getIssuesStatus(doCleanup) + ': ' + filterCount);
        logger(JSON.stringify(collectedStats, undefined, 2));

        logger(
            '================================================================================================================');
    }
}

// *** Basic Functions ***
function isEmptyObject(obj) {
    for (var prop in obj) {
        if (obj.hasOwnProperty(prop)) {
            return false;
        }
    }
    return true;
}

function parseObjectIdToString(id) {
    if (typeof id === 'string') {
        return id;
    } else {
        return id.str;
    }
}

function parseStringToObjectId(id) {
    if (typeof id === 'string') {
        return ObjectId(id);
    } else {
        return id;
    }
}

function validateObjectId(id) {
    var stringId = parseObjectIdToString(id);
    return checkForHexRegExp.test(stringId);
}

var objectIdFromDate = function (date) {
    return Math.floor(date.getTime() / 1000).toString(16) + '0000000000000000';
};
var dateFromObjectId = function (objectId) {
    return new Date(parseInt(objectId.substring(0, 8), 16) * 1000);
};

// Base functions
function printHeader() {
    var logsStatus = getStatus(showLogs);
    var cleanupStatus = getStatus(doCleanup);
    logger(
        '================================================================================================================');
    logger(scriptName + ' ' + version + ' © Sisense | cleanup ' + cleanupStatus + ' | logs ' +
        logsStatus);
    logger(new Date());
    logger(
        '================================================================================================================');
}

function printConfig(config) {
    logger('========== Configuration ==========');
    logger(JSON.stringify(config, undefined, 2));
    logger('====================================');
}

printHeader();
printConfig(config);

// Global variables
var old_ds = 'CRM SmartVideo Engagement';
var new_ds = 'Owned Media SmartVideo Engagement';
var old_ds_obj = {
    'title': 'CRM SmartVideo Engagement',
    'fullname': 'LocalHost/CRM SmartVideo Engagement',
    'id': 'aLOCALHOST_aCRMIAAaSMARTVIDEOIAAaENGAGEMENT',
    'address': 'LocalHost',
    'database': 'aCRMIAAaSmartVideoIAAaEngagement',
    'lastBuildTime': '2018-06-28T13:29:31'
};
var new_ds_obj = {
    'title': 'Owned Media SmartVideo Engagement',
    'fullname': 'LocalHost/Owned Media SmartVideo Engagement',
    'id': 'aLOCALHOST_aOWNEDIAAaMEDIAIAAaSMARTVIDEOIAAaENGAGEMENT',
    'address': 'LocalHost',
    'database': 'aOwnedIAAaMediaIAAaSmartVideoIAAaEngagement'
};
var replaceDictionary = [
    {
        from: 'Sessions.sessionstartdate1 (Calendar)',
        to: 'Daily.sessionstartdate1 (Calendar)'
    }
];
// Functions
var bulkDashboards = prismWebDB.getCollection('dashboards').initializeUnorderedBulkOp();
var bulkWidgets = prismWebDB.getCollection('widgets').initializeUnorderedBulkOp();

function findDifferences(objectA, objectB) {
    var propertyChanges = [];
    var objectGraphPath = ['this'];
    (function (a, b) {
        if (a.constructor == Array) {
            // BIG assumptions here: That both arrays are same length, that
            // the members of those arrays are _essentially_ the same, and
            // that those array members are in the same order...
            for (var i = 0; i < a.length; i++) {
                objectGraphPath.push('[' + i.toString() + ']');
                arguments.callee(a[i], b[i]);
                objectGraphPath.pop();
            }
        } else if (a.constructor == Object || (a.constructor != Number &&
            a.constructor != String && a.constructor != Date &&
            a.constructor != RegExp && a.constructor != Function &&
            a.constructor != Boolean)) {
            // we can safely assume that the objects have the
            // same property lists, else why compare them?
            for (var property in a) {
                objectGraphPath.push(('.' + property));
                if (a[property]) {
                    if (a[property].constructor != Function) {
                        arguments.callee(a[property], b[property]);
                    }
                    objectGraphPath.pop();
                }

            }
        } else if (a.constructor != Function) { // filter out functions
            if (a != b) {
                propertyChanges.push(
                    { 'property': objectGraphPath.join(''), 'objectA': a, 'objectB': b });
            }
        }
    })(objectA, objectB);
    return propertyChanges;
}

function printDIMStats(metadataObj, target) {
    var sortable = [];
    for (var dim in metadataObj) {
        sortable.push([dim, metadataObj[dim]]);
    }
    sortable.sort(function (a, b) {
        return b[1] - a[1];
    });

    if (sortable.length == 0) {
        logger(' No data for ' + target);
    } else {
        logger(' Dimension usage stats in ' + target);
        sortable.forEach(function (elem, index, arr) {
            logger('  - ' + elem[0] + ': ' + elem[1]);

        });
    }
}

function matchNewDS(metadataObj, newMetadataObj, target) {
    logger(' Dimension usage stats in ' + target);
    for (var dim in metadataObj) {
        logger(dim + ' - old: ' + metadataObj[dim] + ' new: ' + newMetadataObj[dim]);
        //findByDIM(dim);
    }

}

function replaceDS(jaql, dash) {
    jaql.datasource = new_ds_obj;
    replaceDictionary.forEach(function (pair) {
        if (jaql.dim === pair.from) {
            jaql.dim = pair.to;
        }
    });
    bulkDashboards.find({ _id: dash._id }).updateOne(dash);
}

function replaceWidgetDS(jaql, widget) {
    jaql.datasource = new_ds_obj;
    replaceDictionary.forEach(function (pair) {
        if (jaql.dim === pair.from) {
            jaql.dim = pair.to;
        }
    });
    bulkWidgets.find({ _id: widget._id }).updateOne(widget);
}

function findByDIM(dim) {
    var result = prismWebDB.getCollection('dashboards')
        .find({ 'filters.jaql.dim': { $in: [dim] } })
        .toArray();
    prismWebDB.getCollection('dashboards').find({ 'defaultFilters.jaql.dim': { $in: [dim] } });
    prismWebDB.getCollection('widgets')
        .find({ 'metadata.panels.items.jaql.dim': { $in: [dim] } });

    result.forEach(function (item) {
        logger('   ' + item.title);
    });
}

// Main script

var loadedFromAnotherScript = true;
load('../mongo_scripts/dim_analyzer.js');
logger('   ');
logger('Compare two datasources usage');
//doCleanup = true;

var old_stat = datasourcesObj[old_ds];
var new_stat = datasourcesObj[new_ds];
var fCount = prismWebDB.getCollection('dashboards')
    .count({ 'filters.jaql.datasource.title': { $in: [old_ds] } });
var dfCount = prismWebDB.getCollection('dashboards')
    .count({ 'defaultFilters.jaql.datasource.title': { $in: [old_ds] } });
var dsCount = prismWebDB.getCollection('dashboards')
    .count({ 'datasource.title': { $in: [old_ds] } });
var wCount = prismWebDB.getCollection('widgets')
    .count({ 'metadata.panels.items.jaql.datasource.title': { $in: [old_ds] } });
logger('Old cube: ' + fCount + ' ' + 'filters');
logger('Old cube: ' + dfCount + ' ' + 'default filters');
logger('Old cube: ' + dsCount + ' ' + 'dashboard datasources');
logger('Old cube: ' + wCount + ' ' + 'widgets');

//logger(JSON.stringify(old_stat, undefined, 2));
logger('   ');
//logger(JSON.stringify(new_stat, undefined, 2));
//logger('   ');
//var result = findDifferences(new_stat, old_stat);
//print(JSON.stringify(result, undefined, 2));
if (old_stat) {
    Object.keys(old_stat).forEach(function (key) {
        var values = old_stat[key];
        var new_values = new_stat[key];

        if (typeof values == 'object') {
            //logger('Old cube: ' + old_ds);
            //printDIMStats(values, key);
            matchNewDS(values, new_values, key);
            //logger('New cube: ' + new_ds);
            //printDIMStats(new_values, key);
        }
        logger('   ');
    });
}

prismWebDB.getCollection('dashboards')
    .find({ 'filters.jaql.datasource.title': { $in: [old_ds] } })
    .forEach(function (dash) {
        logger(' ' + dash._id);
        if (dash.filters) {
            dash.filters.forEach(function (filter) {
                if (filter.jaql && filter.jaql.datasource) {
                    if (filter.jaql.datasource.title === old_ds) {

                        logger('Should replace filters DS ');
                        logger('  ' + filter.jaql.table + ' ' + filter.jaql.column + ' ' +
                            filter.jaql.dim + ' ');
                        //logger(JSON.stringify(filter.jaql, undefined, 2));
                        replaceDS(filter.jaql, dash);
                    }
                }
            });
        }
        logger('   ');
    });
prismWebDB.getCollection('dashboards')
    .find({ 'defaultFilters.jaql.datasource.title': { $in: [old_ds] } }).forEach(function (dash) {
    logger(' ' + dash._id);
    if (dash.defaultFilters) {
        dash.defaultFilters.forEach(function (filter) {
            if (filter.jaql && filter.jaql.datasource) {
                if (filter.jaql.datasource.title === old_ds) {
                    logger('   ');
                    logger('Should replace default filters DS ');
                    //logger(JSON.stringify(filter.jaql, undefined, 2));
                    logger('  ' + filter.jaql.table + ' ' + filter.jaql.column + ' ' +
                        filter.jaql.dim + ' ');
                    replaceDS(filter.jaql, dash);
                }
            }
        });
    }
    logger(' ');
});
prismWebDB.getCollection('widgets')
    .find({ 'metadata.panels.items.jaql.datasource.title': { $in: [old_ds] } })
    .forEach(function (widget) {
        widget.metadata.panels.forEach(function (panel) {
            panel.items.forEach(function (item) {
                if (item.jaql) {
                    if (item.jaql && item.jaql.datasource) {
                        if (item.jaql.datasource.title === old_ds) {
                            logger('   ');
                            logger('Should replace widget items DS ');
                            //logger(JSON.stringify(item.jaql, undefined, 2));
                            logger('  ' + item.jaql.table + ' ' + item.jaql.column + ' ' +
                                item.jaql.dim + ' ');
                            replaceWidgetDS(item.jaql, widget);
                        }
                    }
                }
            });
        });
    });

if (doCleanup) {
    logger(' Bulk execute');
    var resultD = bulkDashboards.execute();
    var resultW = bulkWidgets.execute();
    print(JSON.stringify(resultD, undefined, 2));
    print(JSON.stringify(resultW, undefined, 2));
}



