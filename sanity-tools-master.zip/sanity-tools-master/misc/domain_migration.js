// General Info
var version = '3.0.0';
// Configuration
var showLogs = true;
// todo change to apply
var doUpdate = false;

// todo fill current domain Id
var oldDomainId = '5bbc62c6d74b632c88e64e8e';
// todo fill new domain Id
var newDomainId = '5c98ef4c7879fa1748fa3d2b';
// todo put new domain suffix below
var newDomainSuffix = 'trusteer.il.ibm.com';
var oldDomainSuffix = 'Arizona.sisenselab.int';
var prismWebDB = db.getSiblingDB('prismWebDB');
var prismConfig = db.getSiblingDB('prismConfig');

function logger(msg) {
    if (showLogs) {
        print(msg);
    }
}

logger('=======================================================');
logger('Groups');
logger(' ');
prismWebDB.getCollection('groups')
    .find({ 'ldapDomainId': ObjectId(oldDomainId) })
    .forEach(function (group) {
        logger(group.name + ' dn:' + group.dn);
        if (doUpdate) {
            prismWebDB.getCollection('groups').update(
                { '_id': group._id },
                { $unset: { 'objectSid': '' }, $set: { 'ldapDomainId': ObjectId(newDomainId) } },
                { multi: true }
            );
        }
    });
logger('========================================================');
logger('Users');
logger(' ');
prismWebDB.getCollection('users')
    .find({ 'ldapDomainId': ObjectId(oldDomainId) })
    .forEach(function (user) {
        logger('username: ' + user.userName + ' dn:' + user.dn + ' email:' + user.email);
        logger(' sAMAccountName:' + user.sAMAccountName + ' principalName:' + user.principalName);
        logger(' ');
        if (doUpdate) {
            prismWebDB.getCollection('users').update(
                { '_id': user._id },
                { $unset: { 'objectSid': '' }, $set: { 'ldapDomainId': ObjectId(newDomainId) } },
                { multi: true }
            );
        }
    });

prismWebDB.getCollection('users')
    .find({ 'ldapDomainId': ObjectId(newDomainId) })
    .forEach(function (user) {

        if (user.principalName.indexOf(oldDomainSuffix) !== -1) {
            logger('should update principalName');
            var newPrincipalName = user.principalName.split('@')[0] + '@' + newDomainSuffix;
            logger(' new principalName ' + newPrincipalName);
            if (doUpdate) {
                prismWebDB.getCollection('users').update(
                    { '_id': user._id },
                    { $set: { 'principalName': newPrincipalName } },
                    { multi: true }
                );
            }

        } else {
            logger(' principalname ok');
        }
    });
logger('========================================================');

// todo do force sync ldap after this changes
