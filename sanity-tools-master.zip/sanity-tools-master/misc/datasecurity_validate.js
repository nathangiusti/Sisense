/**
 * Created by yaroslav.korzh on 8/11/2017.
 * Updated 19/02/2019
 */
var version = '3.0.0';
var doCleanup = false;
if (typeof globalCleanup !== 'undefined') {
    // global cleanup
    // comment line below to use local cleanup flag
    doCleanup = globalCleanup;
}

var scriptName = 'Datasecurity validate';

var cleanupStatus = doCleanup ? 'enabled' : 'disabled';
var showLogs = true;
var logsStatus = showLogs ? 'enabled' : 'disabled';

// Common Functions
var checkForHexRegExp = new RegExp('^[0-9a-fA-F]{24}$');
var prismWebDB = db.getSiblingDB('prismWebDB');
var prismConfig = db.getSiblingDB('prismConfig');

function logger(msg) {
    if (showLogs) {
        print(msg);
    }
}

function getIssuesStatus(flag) {
    return flag ? 'fixed' : 'found';
}

function collectStats(key, value) {
    if (typeof collectedStats !== 'undefined') {
        if (collectedStats[key]) {
            collectedStats[key] += value;
        } else {
            collectedStats[key] = value;
        }
    } else {
        collectedStats = {};
        collectedStats[key] = value;
    }
}

function printStats() {
    if (typeof globalRun == 'undefined') {
        logger(scriptName + ' statistics ' + ' © Sisense');
        logger('Total issues ' + getIssuesStatus(doCleanup) + ': ' + filterCount);
        print(JSON.stringify(collectedStats, undefined, 2));

        logger(
            '================================================================================================================');
    }
}

function printHeader() {
    print(
        '================================================================================================================');
    print(scriptName + ' ' + version + ' © Sisense | cleanup ' + cleanupStatus + ' | logs ' +
        logsStatus);
    print(new Date());
    print(
        '================================================================================================================');
}

var stats = {};

prismWebDB.getCollection('dataContext').find({}).forEach(function (security) {
    var msg = '';
    msg += security.server + ' | ';
    msg += security.table + ' | ';
    msg += security.column + ' | ';

    //msg += security.column + ' | ';
    logger(msg);

    logger('******************************************************************');
});