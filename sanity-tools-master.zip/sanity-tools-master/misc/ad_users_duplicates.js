/**
 * Created by yaroslav.korzh
 * Updated 02/05/2019
 */
// General Info
var version = '3.0.0';
var scriptName = 'Widget duplicates cleaner';

// Configuration
var showLogs = true;
var doCleanup = false;
if (typeof globalCleanup !== 'undefined') {
    // global cleanup
    // comment line below to use local cleanup flag
    doCleanup = globalCleanup;
}

var documentKeys = {
    userName: '$userName',
    _id: '$_id'
};

function logger(msg) {
    if (showLogs) {
        print(msg);
    }
}

var bulk = db.getCollection('users').initializeUnorderedBulkOp();
var results = db.getCollection('users').aggregate([
    {
        $group: {
            _id: {
                //_id: "$_id",
                objectSid: '$objectSid'
            },
            count: { $sum: 1 },
            docs: { $push: documentKeys }
        }
    },
    {
        $match: {
            count: { $gt: 1 }
        }
    }
]).toArray();
results.forEach(function (result, index) {
    result.docs.forEach(function (item, index) {
        if (index > 1) {
            logger(item._id);
            bulk.find({ '_id': item._id }).removeOne();
        }
    });
});

var result = bulk.execute();
logger(result);