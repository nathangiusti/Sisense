// General Info
var version = '3.0.0';

var findURL = new RegExp('https://api.highcharts.com', 'gi');
var replaceURL = 'http://developer.sisense.com';//http://developer.sisense.com

db.getCollection('widgets').find({ script: findURL }).forEach(function (widget) {
    print(widget);
    var newScript = widget.script.replace(findURL, replaceURL);
    db.getCollection('widgets').update(
        { _id: widget._id },
        { $set: { 'script': newScript } },
        { multi: false }
    );
});