// General Info
var version = '3.0.0';
// var statusObj = rs.status();
// var primaryDB = {};
// statusObj.members.forEach(function(member){
// 	print(member.name + ' ' + member.state);
// 	if (member.state == 1) {
// 		primaryDB = member;
// 		print(' Is primary DB ');
// 	}
// })

//connection = new Mongo(primaryDB.name);
db = connect('localhost:27019/admin', 'RootUser', 'RepoAdmin!');//
//db = connection.getDB('prismWebDB');

var prismWebDB = db.getSiblingDB('prismWebDB');
var result = prismWebDB.getCollection('widgets').find({}).toArray();
print('Widgets count on primary ' + result.length);