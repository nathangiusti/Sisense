// General Info
var version = '3.0.0';

conn = new Mongo('localhost:27020');
dbBkp = conn.getDB('prismWebDB');

db.users.find({ active: false }).forEach(function (user) {
    var userBkp = dbBkp.users.findOne({ 'email': user.email });
    if (userBkp) {
        // remove corrupted
        db.users.deleteOne({ _id: user._id }, {});
        // insert backup'ed
        db.users.insert(userBkp);
    }
});