db = connect('localhost:27022/prismWebDB');

db.getCollection('users').findOne();

db.mycollection.findOne();
db.getCollectionNames().forEach(function (collection) {
    print(collection);
});

/**
 * Created by yaroslav.korzh on 8/11/2017.
 * Updated 11/06/2018
 */
var version = '3.0.0';
var doCleanup = false;
if (typeof globalCleanup !== 'undefined') {
    // global cleanup
    // comment line below to use local cleanup flag
    doCleanup = globalCleanup;
}

var cleanupStatus = doCleanup ? 'enabled' : 'disabled';
var showLogs = true;
var logsStatus = showLogs ? 'enabled' : 'disabled';
var showUserAndProxy = false;
var showParentInfo = true;

// Common Functions
var checkForHexRegExp = new RegExp('^[0-9a-fA-F]{24}$');
var prismWebDB = db.getSiblingDB('prismWebDB');
var prismConfig = db.getSiblingDB('prismConfig');

// *** Basic Functions ***
function isEmptyObject(obj) {
    for (var prop in obj) {
        if (obj.hasOwnProperty(prop)) {
            return false;
        }
    }
    return true;
}

function parseObjectIdToString(id) {
    if (typeof id === 'string') {
        return id;
    } else {
        return id.str;
    }
}

function parseStringToObjectId(id) {
    if (typeof id === 'string') {
        return ObjectId(id);
    } else {
        return id;
    }
}

function validateObjectId(id) {
    var stringId = parseObjectIdToString(id);
    return checkForHexRegExp.test(stringId);
}

var objectIdFromDate = function (date) {
    return Math.floor(date.getTime() / 1000).toString(16) + '0000000000000000';
};
var dateFromObjectId = function (objectId) {
    return new Date(parseInt(objectId.substring(0, 8), 16) * 1000);
};

function logger(msg) {
    if (showLogs) {
        print(msg);
    }
}

function getWidgetInfo(id, sourceSearch) {
    if (showParentInfo) {
        var searchId = parseStringToObjectId(id);
        var result = db.getCollection('widgets').find({
            _id: searchId
        }).toArray();
        db.getCollection('widgets').find({
            _id: searchId
        }).forEach(function (widget) {
            var text = 'widget info';
            if (sourceSearch) {
                text = 'Parent ' + text;
            }
            logger('********************* ' + text + ' ********************************');
            logger(widget.title + ' | ' + widget.oid + ' | ' + widget._id + ' | ' + widget.source +
                ' | ' + widget.created + ' | ' + widget.dashboardid + ' | ' + widget.owner + ' | ' +
                widget.instanceType + ' | ' + widget.userId + ' | ' + widget.lastUpdated + ' | ' +
                widget.lastUsed);
            //getDashboardInfo(widget.dashboardid)
            if (widget.source) {
                getWidgetInfo(widget.source, true);
            }
            logger('******************************************************************');
        });

        if (result.length == 0) {
            var text = 'widget not found';
            if (sourceSearch) {
                text = 'Parent ' + text;
            }
            logger('************************* ' + text + ' *******************************');
        }
    }

}

function getDashboardInfo(id, sourceSearch) {
    if (showParentInfo) {
        logger('Sourced from:');
        var searchId = parseStringToObjectId(id);
        var searchObj = {
            instanceType: 'owner'
        };
        if (sourceSearch) {
            searchObj['_id'] = searchId;
        } else {
            searchObj['oid'] = searchId;
        }
        var result = db.getCollection('dashboards').find(searchObj).toArray();

        db.getCollection('dashboards').find(searchObj).forEach(function (dash) {
            var text = 'Dashboard info';
            if (sourceSearch) {
                text = 'Parent ' + text;
            }
            logger('********************* ' + text + ' ********************************');
            logger('Dashboard: ' + dash._id + ' | ' + dash.title + ' | ' + dash.oid + ' | ' +
                dash.instanceType + ' | ' + dash.owner + ' | ' + dash.source + ' | ' +
                dash.lastUpdated);
            if (dash.source) {
                getDashboardInfo(dash.source, true);
            }
            logger('*********************************************************************');
        });

        if (result.length == 0) {
            var text = 'dashboard not found';
            if (sourceSearch) {
                text = 'Parent ' + text;
            }
            logger('************************* ' + text + '*******************************');
        }
    }

}

var bulk = db.getCollection('widgets').initializeUnorderedBulkOp();
var owners = {};
var results = db.getCollection('widgets').aggregate([
    {
        $group: {
            _id: {
                //_id: "$_id",
                title: '$title',
                oid: '$oid',
                userId: '$userId',
                instanceType: '$instanceType',
                dashboardid: '$dashboardid'
                //source: '$source'
            },
            count: { $sum: 1 },
            docs: { $push: '$_id' }
        }
    },
    {
        $match: {
            count: { $gt: 1 }
        }
    }
]).toArray();

if (results.length > 0) {
    var action = doCleanup ? 'start cleaning' : 'set "doCleanup = true;" to start cleaning';
    var deleteIdsArr = [];

    print('Widget duplicates cleaner ' + version + ' © Sisense | widget cleanup ' + cleanupStatus +
        ' | logs ' + logsStatus);
    print(
        '================================================================================================================');
    print('Found ' + results.length + ' duplicate widget instances, ' + action);
    print(
        '================================================================================================================');
    for (var i = 0; i < results.length; i++) {
        var result = results[i];

        var data = {};
        var isOwner = result._id.instanceType === 'owner';

        if (result) {
            if (isOwner) {
                var owner = {};

                db.getCollection('users').find({ _id: result._id.userId }).forEach(function (user) {
                    logger('User: ' + user.userName + ' | ' + user._id);
                    Object.keys(owners).forEach(function (item) {
                        var userObj = owners[item];
                        if (userObj.name == user.userName) {
                            owner = owners[user.userName];
                        }
                    });

                    data.user = user.userName;
                    owner.name = user.userName;

                    db.getCollection('dashboards').find({
                        oid: result._id.dashboardid,
                        instanceType: result._id.instanceType
                    }).forEach(function (dash) {
                        var dashboard = {};
                        logger('Dashboard: ' + dash.title + ' | ' + dash.oid + ' | ' +
                            dash.instanceType + ' | ' + dash.owner + ' | ' + dash.created + ' | ' +
                            dash.lastUpdated + ' | ' + dash.source);
                        data.dashoid = dash.oid;
                        data.dashboardtitle = dash.title;
                        dashboard.dashboardId = dash.oid;
                        dashboard.dashboardtitle = dash.title;

                        if (!owner.dashboards) {
                            owner.dashboards = {};
                        }
                        if (!owner.dashboards[dashboard.dashboardId.valueOf()]) {
                            owner.dashboards[dashboard.dashboardId.valueOf()] = dashboard;
                        }
                        if (dash.source !== 'undefined') {
                            getDashboardInfo(dash.source, true);
                        }

                    });
                    owners[owner.name] = owner;
                });
                var dashboardCount = db.getCollection('dashboards').count({
                    oid: result._id.dashboardid,
                    instanceType: result._id.instanceType
                });
            } else if (showUserAndProxy) {
                logger('Result is ' + result._id.instanceType +
                    ' instance. Fixing owner instances solves it.');//+ ' | ' + result._id.owner + ' | ' + result._id.userId
                //logger('Widget: ' + result._id.title + ' | ' + result._id.oid + ' | ' + result._id._id + ' | ' + result._id.source  +' | ')
                db.getCollection('widgets').find({
                    oid: result._id.oid,
                    userId: result._id.userId,
                    instanceType: result._id.instanceType
                }).sort({ lastUpdated: -1 }).forEach(function (widget) {
                    logger(widget.title + ' | ' + widget.oid + ' | ' + widget._id + ' | ' +
                        widget.source + ' | ' + widget.instanceType + ' | ' + widget.owner + ' | ' +
                        widget.userId + ' | ' + widget.dashboardid + ' | ' + widget.lastUpdated +
                        ' | ' + widget.created + ' | ' + widget.lastUsed);
                    getWidgetInfo(widget.source, true);
                });
                //logger('******************************************************************');
            }

            if (dashboardCount > 0 && isOwner) {
                var resObj = {};
                logger('You have multiple owner widgets with the same oid:');
                logger(
                    ' title |  oid  |  _id  | source  | instanceType | owner | user | dashboardid |  lastUpdated  | created  | lastUsed ');
                var widgetsArr = db.getCollection('widgets')
                    .find({
                        oid: result._id.oid,
                        userId: result._id.userId,
                        instanceType: result._id.instanceType
                    })
                    .sort({ lastUpdated: -1 })
                    .toArray();
                db.getCollection('widgets').find({
                    oid: result._id.oid,
                    userId: result._id.userId,
                    instanceType: result._id.instanceType
                }).sort({ lastUpdated: -1 }).forEach(function (widget) {
                    logger('==================== Widget ========================');
                    logger(widget.title + ' | ' + widget.oid + ' | ' + widget._id + ' | ' +
                        widget.source + ' | ' + widget.created + ' | ' + widget.dashboardid +
                        ' | ' + widget.owner + ' | ' + widget.instanceType + ' | ' + widget.userId +
                        ' | ' + widget.lastUpdated + ' | ' + widget.lastUsed);
                    if (widget.source) {
                        getWidgetInfo(widget.source, true);
                    }
                    logger('====================================================');
                });

                if (doCleanup) {
                    for (var ii = 1; ii < widgetsArr.length; ii++) {
                        var widget = widgetsArr[ii];

                        //var res = db.widgets.deleteOne({"_id": widget._id});
                        //bulk.find( {"_id": widget._id} ).removeOne();
                        //logger(widget.title + ' deleted: ' + res.deletedCount);
                        deleteIdsArr.push(widget._id);
                    }
                    //logger('----------------------------------------------------');
                    logger('Now dashboard owner ' + data.user + ' needs to republish ' +
                        data.dashboardtitle + ' with id ' + data.dashoid);
                } else {

                }

                logger('    ');
            } else if (dashboardCount === 0) {
                logger('no related dashboard found, you need to delete ' + result.docs.length +
                    ' redundant widgets');
                for (var k = 0; k < result.docs.length; k++) {
                    var res = result.docs[k];

                    db.getCollection('widgets')
                        .find({ _id: res })
                        .sort({ lastUpdated: -1 })
                        .forEach(function (widget) {
                            logger(widget.title + ' | ' + widget.oid + //' | ' + widget._id.getTimestamp().getTime() +
                                ' | ' + widget._id + ' | ' + widget.instanceType + ' | ' +
                                widget.lastUpdated + ' | ' + widget.created + ' | ' +
                                widget.lastUsed);
                            var res = db.widgets.deleteOne({ '_id': widget._id });
                            logger(widget.title + ' deleted: ' + res.deletedCount);
                        });

                }
                logger(
                    '==================================================================================================================================================================================================================');
            }
        }

    }

    print('========== ACTIONS ==========');
    logger(
        'to normalize these dashboards we remove all the junk widgets, most recently updated is kept, all others should be removed');
    logger('to delete widgets set flag doCleanup = true');
    logger('And you need these users to republish their dashboards');
    logger('After running this script for cleaning');
    print('=============================');

    Object.keys(owners).forEach(function (item) {

        var userObj = owners[item];

        print(userObj.name + ' should republish dashboards:');
        Object.keys(userObj.dashboards).forEach(function (key, value) {
            item = userObj.dashboards[key];
            print(item.dashboardtitle + ' with oid ' + item.dashboardId);
        });
        print('--------------------------');
    });
    if (doCleanup) {
        var deleteResult = db.getCollection('widgets').deleteMany(
            { '_id': { $in: deleteIdsArr } }
        );
        print('Deleted: ' + deleteResult.deletedCount);
    }
} else {
    print('Your mongo is free from widget duplicates');
}