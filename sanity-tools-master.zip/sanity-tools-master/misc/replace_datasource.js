// General Info
var version = '3.0.0';

var address = '10.50.6.13';
var newAddress = 'LocalHost';

function replaceDatasource(datasource) {
    if (datasource.fullname) {
        datasource.fullname = datasource.fullname.replace(address, newAddress);
    }
    if (datasource.id) {
        var searchStr = address.replace('.', 'LgAa');
        searchStr = 'a' + searchStr.toUpperCase() + '_a';
        var replaceStr = 'a' + newAddress.toUpperCase() + '_a';
        datasource.id = datasource.id.replace(searchStr, replaceStr);
    }

    if (datasource.address) {
        datasource.address = datasource.address.replace(address, newAddress);
    }
    return datasource;
}

try {
    db.getCollection('dashboards').find({ 'datasource.address': address }).forEach(function (e, i) {
        if (e.datasource) {
            e.datasource = replaceDatasource(e.datasource);
        }
        if (e.widgets) {
            e.widgets.forEach(function (r, s) {
                if (r.datasource) {
                    r.datasource = replaceDatasource(r.datasource);
                }

                if (r.metadata && r.metadata.panels && r.metadata.panels.items) {
                    r.metadata.panels.items.forEach(function (h) {
                        if (h.jaql && h.jaql.datasource) {
                            h.jaql.datasource = replaceDatasource(h.jaql.datasource);
                        }
                    });
                }

            });
        }
        if (e.filters) {
            e.filters.forEach(function (r, s) {
                if (r.jaql) {
                    var datasource = r.jaql.datasource;
                } else {
                    print('no r.jaql');
                }

                if (datasource) {
                    datasource = replaceDatasource(datasource);
                }

                if (r.levels) {
                    r.levels.forEach(function (level) {
                        var datasource = level.datasource;
                        if (datasource) {
                            datasource = replaceDatasource(datasource);
                        }
                    });
                }
            });
        }
        if (e.defaultFilters) {
            e.defaultFilters.forEach(function (r, s) {
                if (r.jaql) {
                    var datasource = r.jaql.datasource;
                } else {
                    print('no r.jaql');
                }
                if (datasource) {
                    datasource = replaceDatasource(datasource);
                }
                if (r.levels) {
                    r.levels.forEach(function (level) {
                        var datasource = level.datasource;
                        if (datasource) {
                            datasource = replaceDatasource(datasource);
                        }
                    });
                }

            });
        }

        db.getCollection('dashboards').save(e);
    });
} catch (e) {
    print(e);
}

try {
    db.getCollection('widgets').find({}).forEach(function (e, i) {
        if (e.datasource) {
            e.datasource = replaceDatasource(e.datasource);

        }
        if (e.metadata && e.metadata.panels && e.metadata.panels.items) {
            e.metadata.panels.items.forEach(function (h) {
                if (h.jaql && h.jaql.datasource) {
                    h.jaql.datasource = replaceDatasource(h.jaql.datasource);
                }
            });
        }
        db.getCollection('widgets').save(e);
    });
} catch (error) {
    print(error);
}