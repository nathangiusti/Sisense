// General Info
var version = '3.0.0';

var collections = prismWebDB.getCollectionNames();
var limit = 16777216;
print('  ');
print('Collection items count: ');
var maxSize = 0;
collections.forEach(function (item) {
    var collectionTotal = prismWebDB.getCollection(item).count();
    print(item + ' : ' + collectionTotal + ' items');
    print(' ');
    prismWebDB.getCollection(item).find({}).forEach(function (item) {
        var size = Object.bsonsize(item);
        print('item size: ' + size);
        if (size > maxSize) {
            maxSize = size;
            print('new max size: ' + maxSize);
        }

        if (size > limit) {
            print('document bigger than mongo limit ');
        }
    });
});
print('max size: ' + maxSize);