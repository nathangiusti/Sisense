// General Info
var version = '3.0.0';

var groupId = '5c11e00312663a0958c3497f';
db.getCollection('dataContext')
    .find({ table: 'CompanyDim', column: 'GroupAccountDepartmentID', allMembers: true })
    .forEach(function (rule) {
        var onlyUser = false;
        var userCount = 0;

        rule.shares.forEach(function (share) {
            print(share.type + ' ' + share.partyId);

            if (share.type == 'user' && groupId != '') {
                db.getCollection('users').update(
                    { _id: share.partyId },
                    { $push: { groups: groupId } }
                );
                userCount += 1;
            }

        });

        if (rule.shares.length === userCount) {
            db.getCollection('dataContext').deleteOne({ '_id': rule._id });
        }

        print('=============================');
    });

