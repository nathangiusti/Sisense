// General Info
var version = '3.0.0';

var oldCubeId = '5c087460a7477c2bbcdf5497';
var newCubeId = '5c07021eef91784410d46fd0';
var doUpdate = false;
db.getCollection('dataContext').find({ cubeId: ObjectId(oldCubeId) }).forEach(function (rule) {
    print('rule:' + rule._id);
    if (doUpdate) {
        db.getCollection('dataContext').updateOne(
            { '_id': rule._id },
            { $set: { 'cubeId': ObjectId(newCubeId) } }
        );
    }
});