// General Info
var version = '3.0.0';

var doUpdate = false;

var oldDomainId = '';
var newDomainId = '5c98ef4c7879fa1748fa3d2b';
db.getCollection('groups')
    .find({ 'ldapDomainId': ObjectId(oldDomainId) })
    .forEach(function (group) {
        if (doUpdate) {
            db.getCollection('groups').update(
                { '_id': group._id },
                { $unset: { 'objectSid': '' }, $set: { 'ldapDomainId': ObjectId(newDomainId) } },
                { multi: true }
            );
        }
    });
db.getCollection('users').find({ 'ldapDomainId': ObjectId(oldDomainId) }).forEach(function (user) {
    if (doUpdate) {
        db.getCollection('users').update(
            { '_id': user._id },
            { $unset: { 'objectSid': '' }, $set: { 'ldapDomainId': ObjectId(newDomainId) } },
            { multi: true }
        );
    }
});

/*
db.getCollection('users').find({ 'ldapDomainId': ObjectId(newDomainId) }).forEach(function(user){
	print(user.principalName);
	if (user.principalName.indexOf('@il.ibm.com') !== -1) {
		print('should update principalName');
		var newPrincipalName = user.principalName.split('@')[0] + '@trusteer.il.ibm.com';
		print(' new principalName ' + newPrincipalName);
		if(doUpdate) {
			db.getCollection('users').update(
				{ '_id': user._id }, 
				{ $set: { 'principalName': newPrincipalName }}, 
				{ multi: true }
			)
		}
		
	}
	else {
		print(' principalname ok' )
	}
});
*/

// do force sync ldap after this changes
