// General Info
var version = '3.0.0';

var prismWebDB = db.getSiblingDB('prismWebDB');

prismWebDB.getCollection('users')
    .find({ ldapDomainId: { $type: 'string' } })
    .forEach(function (user) {
        prismWebDB.getCollection('users').updateOne(
            { _id: user._id },
            { $set: { ldapDomainId: ObjectId(user.ldapDomainId) } },
            { upsert: true }
        );
    });