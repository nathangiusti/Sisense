/**
 * Created by yaroslav.korzh
 * Updated 02/05/2019
 */
// General Info
var version = '3.0.0';
var scriptName = 'Scripts loader';

// Configuration
var showLogs = true;
var doCleanup = false;
var globalCleanup;
if (typeof cleanup !== 'undefined') {
    doCleanup = cleanup;
    globalCleanup = doCleanup;
}

var globalRun = true;
var collectedStats = {};
var timeout = 1000;
var showDBStats = false;
var prismWebDB = db.getSiblingDB('prismWebDB');
var prismConfig = db.getSiblingDB('prismConfig');

function logger(msg) {
    if (showLogs) {
        print(msg);
    }
}

function getStatus(flag) {
    return flag ? 'enabled' : 'disabled';
}

function getIssuesStatus(flag) {
    return flag ? 'fixed' : 'found';
}

var logsStatus = getStatus(showLogs);
var cleanupStatus = getStatus(doCleanup);
var dbStatistics = prismWebDB.stats(1024);
var dbKeys = ['ns', 'size', 'count', 'avgObjSize', 'storageSize', 'nindexes', 'indexSizes'];

function printHeader() {
    print(
        '================================================================================================================');
    print(scriptName + ' ' + version + ' © Sisense | cleanup ' + cleanupStatus + ' | logs ' +
        logsStatus);

    print(new Date());
    print('DB stats: ');
    print(JSON.stringify(dbStatistics, undefined, 2));
    print('maxBsonObjectSize ' + prismWebDB.isMaster().maxBsonObjectSize);
    var collections = prismWebDB.getCollectionNames();

    print('  ');
    print('Collection items count: ');
    collections.forEach(function (item) {
        var collectionTotal = prismWebDB.getCollection(item).count();
        print(item + ' : ' + collectionTotal + ' items');
    });

    var sortChange = prismWebDB.adminCommand(
        { 'setParameter': 1, 'internalQueryExecMaxBlockingSortBytes': 134217728 }); // old sort = 33554432
    //print(JSON.stringify(sortChange, undefined, 2));

    print(
        '================================================================================================================');
}

function postProcessExecution() {
    var collection = prismWebDB.getCollectionNames();
    if (doCleanup) {
        if (showDBStats) {
            print(' ');
            print('MongoDB stats: ');
            print(JSON.stringify(dbStatistics, undefined, 2));

        }
        logger('Free space from MongoDB ');
        print(' ');
        collection.forEach(function (result) {
            var r1 = prismWebDB.runCommand({ collStats: result, scale: 1024 });
            if (showDBStats) {
                dbKeys.forEach(function (key) {
                    var val = r1[key];
                    logger('  ' + key + ': ' + JSON.stringify(val));
                });
                print('  ');
            }

            var r2 = prismWebDB.runCommand({ compact: result });
            var r3 = prismWebDB.runCommand({ collStats: result, scale: 1024 });
            if (showDBStats) {
                dbKeys.forEach(function (key) {
                    var val = r3[key];
                    logger('  ' + key + ': ' + JSON.stringify(val));
                });
                print('  ');
            }

        });
        prismWebDB.repairDatabase();
    } else {
        if (showDBStats) {
            print(' ');
            print('MongoDB stats: ');
            collection.forEach(function (result) {
                var r1 = prismWebDB.runCommand({ collStats: result, scale: 1024 });

                dbKeys.forEach(function (key) {
                    var val = r1[key];
                    logger('  ' + key + ': ' + JSON.stringify(val));
                });
                print('  ');

            });
        }
    }
    print('   ');
    print('MongoDB stats: ');
    print(JSON.stringify(prismWebDB.stats(1024), undefined, 2));
    print('   ');

    var collections = prismWebDB.getCollectionNames();
    print('Collection items count: ');
    collections.forEach(function (item) {
        var collectionTotal = prismWebDB.getCollection(item).count();
        print(' ' + item + ' : ' + collectionTotal + ' items');
    });

    var sortChange = prismWebDB.adminCommand(
        { 'setParameter': 1, 'internalQueryExecMaxBlockingSortBytes': 33554432 }); // old sort = 134217728
    //print(JSON.stringify(sortChange, undefined, 2));
}

function printSummary() {
    print('   ');
    print(
        '================================================================================================================');
    logger('Scripts statistics ' + ' © Sisense');

    //print(JSON.stringify(collectedStats, undefined, 2));
    var total = 0;
    Object.keys(collectedStats).forEach(function (key, index, array) {
        var value = collectedStats[key];
        print(' - ' + key + ': ' + value + ' items');
        total += value;
    });
    logger('Total issues ' + getIssuesStatus(doCleanup) + ': ' + total);

    logger(
        '================================================================================================================');
}

printHeader();
load('widget_duplicates_cleaner.js');
sleep(timeout);
load('cube_shares_duplicates.js');
sleep(timeout);
load('dash_shares_duplicates.js');
sleep(timeout);
load('unused_cubes_cleaner.js');
sleep(timeout);
load('user_validate.js');
sleep(timeout);
load('user_groups.js');
sleep(timeout);
load('jobs_validate.js');
sleep(timeout);
load('dashboard_validate.js');
sleep(timeout);
load('dashboard_widget_duplicates.js');
sleep(timeout);
// load('dim_analyzer.js');
// sleep(timeout);

logger('============================================');
logger('Post-processing script changes');
print(' ');
postProcessExecution();
printSummary();
logger('Scripts have finished execution successfully ' + ' © Sisense');