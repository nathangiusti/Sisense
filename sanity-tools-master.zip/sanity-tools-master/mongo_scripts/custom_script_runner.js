/**
 * Created by yaroslav.korzh
 * Updated 02/05/2019
 */
// General Info
var version = '3.0.0';
var scriptName = 'Custom Script Runner';

// Configuration
var showLogs = true;
var doCleanup = false;
var globalCleanup;
if (typeof cleanup !== 'undefined') {
    doCleanup = cleanup;
    globalCleanup = doCleanup;
}

var globalRun = true;
var collectedStats = {};
var timeout = 1000;
var prismWebDB = db.getSiblingDB('prismWebDB');
var prismConfig = db.getSiblingDB('prismConfig');

function logger(msg) {
    if (showLogs) {
        print(msg);
    }
}

function getStatus(flag) {
    return flag ? 'enabled' : 'disabled';
}

function getIssuesStatus(flag) {
    return flag ? 'fixed' : 'found';
}

var logsStatus = getStatus(showLogs);
var cleanupStatus = getStatus(doCleanup);

function printHeader() {
    print('===============================================================');
    print(scriptName + ' ' + version + ' © Sisense | cleanup ' + cleanupStatus + ' | logs ' +
        logsStatus);
    print('=============================================================');
    prismWebDB.adminCommand(
        { 'setParameter': 1, 'internalQueryExecMaxBlockingSortBytes': 134217728 }); // old sort = 33554432
}
function printSummary() {
    prismWebDB.adminCommand(
        { 'setParameter': 1, 'internalQueryExecMaxBlockingSortBytes': 33554432 }); // old sort = 134217728
    print('   ');
    print('=============================================================');
    logger('Scripts statistics ' + ' © Sisense');
}

printHeader();

// TODO put here path to script you want to run
load('../misc/domain_migration.js');
//load('../misc/test_size.js');

logger('===========================================================');

printSummary();
logger('Script has finished execution successfully ' + ' © Sisense');