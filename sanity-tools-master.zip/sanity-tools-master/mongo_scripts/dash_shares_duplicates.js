﻿/**
 * Created by yaroslav.korzh
 * Updated 02/05/2019
 */
// General Info
var version = '3.0.0';
var scriptName = 'Dash shares duplicates';

// Configuration
var showLogs = true;
var doCleanup = false;
if (typeof globalCleanup !== 'undefined') {
    // global cleanup
    // comment line below to use local cleanup flag
    doCleanup = globalCleanup;
}

var showShareDuplicates = false;
var fixOwners = doCleanup;
var config = {
    cleanup: {
        doCleanup: doCleanup,
        fixOwners: fixOwners
    },
    logging: {
        showLogs: showLogs,
        showShareDuplicates: showShareDuplicates
    }
};

// Common Functions
var checkForHexRegExp = new RegExp('^[0-9a-fA-F]{24}$');
var prismWebDB = db.getSiblingDB('prismWebDB');
var prismConfig = db.getSiblingDB('prismConfig');

function getStatus(flag) {
    return flag ? 'enabled' : 'disabled';
}

function logger(msg) {
    if (showLogs) {
        print(msg);
    }
}

function getIssuesStatus(flag) {
    return flag ? 'fixed' : 'found';
}

function collectStats(key, value) {
    if (typeof collectedStats !== 'undefined') {
        if (collectedStats[key]) {
            collectedStats[key] += value;
        } else {
            collectedStats[key] = value;
        }
    } else {
        collectedStats = {};
        collectedStats[key] = value;
    }
}

function printStats() {
    if (typeof globalRun == 'undefined') {
        logger(scriptName + ' statistics ' + ' © Sisense');
        logger('Total issues ' + getIssuesStatus(doCleanup) + ': ' + filterCount);
        print(JSON.stringify(collectedStats, undefined, 2));

        logger(
            '================================================================================================================');
    }
}

// *** Basic Functions ***
function isEmptyObject(obj) {
    for (var prop in obj) {
        if (obj.hasOwnProperty(prop)) {
            return false;
        }
    }
    return true;
}

function parseObjectIdToString(id) {
    if (typeof id === 'string') {
        return id;
    } else {
        return id.str;
    }
}

function parseStringToObjectId(id) {
    if (typeof id === 'string') {
        return ObjectId(id);
    } else {
        return id;
    }
}

function validateObjectId(id) {
    var stringId = parseObjectIdToString(id);
    return checkForHexRegExp.test(stringId);
}

var objectIdFromDate = function (date) {
    return Math.floor(date.getTime() / 1000).toString(16) + '0000000000000000';
};
var dateFromObjectId = function (objectId) {
    return new Date(parseInt(objectId.substring(0, 8), 16) * 1000);
};

// Base functions
function printHeader() {
    var logsStatus = getStatus(showLogs);
    var cleanupStatus = getStatus(doCleanup);
    print(
        '================================================================================================================');
    print(scriptName + ' ' + version + ' © Sisense | cleanup ' + cleanupStatus + ' | logs ' +
        logsStatus);
    print(new Date());
    print(
        '================================================================================================================');
}

function printConfig(config) {
    print('========== Configuration ==========');
    print(JSON.stringify(config, undefined, 2));
    print('====================================');
}

printHeader();
printConfig(config);

// Global variables
var maxDuplicates = 0;
var maxShares = 0;
// Functions
var bulk = prismWebDB.getCollection('dashboards').initializeUnorderedBulkOp();
// Main script

prismWebDB.getCollection('dashboards').find({}).forEach(function (dash) {
    //logger('dash shares: ' + dash.shares.length);

    var sharesObj = {};
    var sharesToKeep = [];
    var hasOwnerShare = false;
    var isOwner = dash.instanceType === 'owner';
    if (dash.shares) {
        if (dash.shares.length > maxShares) {
            maxShares = dash.shares.length;
        }
        dash.shares.forEach(function (share, index) {
            //logger('==================== Widget ========================');
            //logger(share.shareId + ' | ' + index + ' | ' + share.type + ' | ' + share.rule );
            if (sharesObj[share.shareId]) {
                sharesObj[share.shareId].count += 1;
                sharesObj[share.shareId].agg.push(share);
            } else {
                sharesObj[share.shareId] = share;
                sharesObj[share.shareId].count = 1;
                sharesObj[share.shareId].agg = [];
                sharesObj[share.shareId].agg.push(share);
                sharesToKeep.push({
                    shareId: share.shareId,
                    type: share.type,
                    rule: share.rule,
                    subscribe: share.subscribe
                });
            }
            if (share.shareId.valueOf() == dash.owner.valueOf() && share.type == 'user') {
                hasOwnerShare = true;
            }
            //logger('====================================================');
        });

        if (!hasOwnerShare) {
            logger('Owner is not in shares');
            collectStats('dashboard_owner_not_in_shares', 1);
            if (fixOwners) {
                sharesToKeep.push({ shareId: dash.owner, type: 'user' });
            }
        }
        Object.keys(sharesObj).forEach(function (item) {

            var share = sharesObj[item];
            if (share.count > 1) {
                if (share.count > maxDuplicates) {
                    maxDuplicates = share.count;
                }
                collectStats('dashboard_shares_duplicates', 1);
                logger('You have duplicates in shares collection for dash');
                logger('Duplicate: ' + item + ' | ' + share.type + ' | ' + share.rule + ' | ' +
                    share.subscribe + ' - count: ' + share.count);

                if (showShareDuplicates) {
                    share.agg.forEach(function (share, index) {
                        logger(share.shareId + ' | ' + index + ' | ' + share.type + ' | ' +
                            share.rule + ' | ' + share.subscribe);
                    });
                }

                logger('--------------------------');
            }

        });
        if (dash.shares.length === sharesToKeep.length && hasOwnerShare) {
            //logger('Shares normalized ');
        } else if (doCleanup || !hasOwnerShare) {
            logger('Keep shares: ' + sharesToKeep.length);
            prismWebDB.getCollection('dashboards').update(
                { '_id': dash._id },
                { $set: { 'shares': sharesToKeep } }
            );
            logger('====================================================');
        }
    } else {
        logger('Dashboard ' + dash._id + ' with  oid: ' + dash.oid + ' user: ' + dash.userId +
            '  has no shares');
        if (doCleanup) {
            if (isOwner) {
                logger('Create shares ');
                prismWebDB.getCollection('dashboards').update(
                    { '_id': dash._id },
                    { $set: { 'shares': [{ shareId: dash.owner, type: 'user' }] } }
                );
            }

            logger('====================================================');
        }
    }

});

if (maxDuplicates > 0) {
    logger('Max duplicates in shares ' + maxDuplicates + ' copies');
} else {
    logger('No duplicates in collection');
}
logger('Max shares array ' + maxShares + ' items');