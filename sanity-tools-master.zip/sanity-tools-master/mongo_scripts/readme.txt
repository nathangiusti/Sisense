# Read Me
## To run general Healthcheck:
In scripts from scripts_loader verify: doCleanup = false;
Run AnalyzeMongo.bat
Open analyzer_results_%host%_%timestamp% and check output
Then, change flag doCleanup to true in scripts that need to perform some cleanup

## To run filter analysis:
Run AnalyzeFilters.bat
Open filter_analyzer_results_%host%_%timestamp% and check output

## To run dimensions analysis:
Run AnalyzeDIMs.bat
Open dimension_analyzer_results_%host%_%timestamp% and check output

## To create scheduled cleaner:
Use scheduled_cleanup.bat
Create windows task to run it with some interval
Results will be stored in the folder with bat file named scheduled_cleaner_%host%_%timestamp%

## To run a separate script in cmd:
###Option 1:
Change in custom_script runner: load('%path_to_script%/%script_name%.js') to point to the script you want to run
Run CustomScriptAnalyzer to run for analyze
Run CustomScriptCleaner to run for cleanup
###Option 2:
Take this string and set script_name to desired script, and output_file_name to desired output file name
In script verify: doCleanup = false;
Run command in cmd: "C:\Program Files\Sisense\Infra\MongoDB\sisenseRepositoryShell.exe" --host mongodb://RootUser:RepoAdmin!@localhost:27018 %script_name%.js > %output_file_name%.json
You can also remove > %output_file_name%.json from this call to see output in cmd directly

## Scripts description:
- scripts_loader - util script to load other scripts, you can comment down any scripts you don't want for healthcheck
### Healthcheck scripts
- widget_duplicates_cleaner - remove duplicates from dashboards & widgets collections of mongodb
- dashboard_widget_duplicates - remove duplicates from dashboard widgets array
- cube_shares_duplicates - remove shares from elasticcubes shares array
- dash_shares_duplicates - remove duplicates from dashboard shares array + fix owner that is not in shares
- user_groups - fixes duplicated user group items
- dashboard_validate - validate dashboard folder, user, ghost widgets on layout and e.t.c
- user_validate - validate user id, groups, role
- jobs_validate - validate scheduled jobs of different kind - job points to existing dashboard
- unused_cubes_cleaner - check elasticcubes collection to see if cube is used in any dashboards and / or widgets
- filter_analyzer - analyze all filters from widgets and dashboards for data security related questions
- dim_analyzer - analyze all dimensions usage in dashboard - filters, widgets for all cubes
### Other scripts
- user_ldap_validate - for ldapDomainId that is a string make it back ObjectId
- widget_duplicates_cleaner_scheduled - copy of widget_duplicates_cleaner with doCleanup = true to run scheduled cleanup
### Not finished scripts 
- ha_cleaner - template for cleaning on HA environment, not finished
- datasecurity_validate - template for validating data security rules to be on existing cube / dimension
- cube_analyze - check used / not used dimensions, dimensions that no longer exist in the cube ( requires cube to be built in ecm 2.0 )
### Util scripts
- compare_objects - util script to compare two similar objects and show their difference
- log_tracer - util script to analyze entries in trace collection


