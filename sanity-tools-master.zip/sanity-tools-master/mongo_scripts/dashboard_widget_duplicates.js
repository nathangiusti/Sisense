﻿/**
 * Created by yaroslav.korzh
 * Updated 02/05/2019
 */
// General Info
var version = '3.0.0';
var scriptName = 'Dashboard wigets duplicates';

// Configuration
var showLogs = true;
var doCleanup = false;
if (typeof globalCleanup !== 'undefined') {
    // global cleanup
    // comment line below to use local cleanup flag
    doCleanup = globalCleanup;
}

var showWidgetInfo = false;
var config = {
    cleanup: {
        doCleanup: doCleanup
    },
    logging: {
        showLogs: showLogs,
        showWidgetInfo: showWidgetInfo
    },
    drillPrefix: '_drill'
};

// Common Functions
var checkForHexRegExp = new RegExp('^[0-9a-fA-F]{24}$');
var prismWebDB = db.getSiblingDB('prismWebDB');
var prismConfig = db.getSiblingDB('prismConfig');

function getStatus(flag) {
    return flag ? 'enabled' : 'disabled';
}

function logger(msg) {
    if (showLogs) {
        print(msg);
    }
}

// *** Basic Functions ***
function isEmptyObject(obj) {
    for (var prop in obj) {
        if (obj.hasOwnProperty(prop)) {
            return false;
        }
    }
    return true;
}

function parseObjectIdToString(id) {
    if (typeof id === 'string') {
        return id;
    } else {
        return id.str;
    }
}

function parseStringToObjectId(id) {
    if (typeof id === 'string') {
        return ObjectId(id);
    } else {
        return id;
    }
}

function validateObjectId(id) {
    var stringId = parseObjectIdToString(id);
    return checkForHexRegExp.test(stringId);
}

var objectIdFromDate = function (date) {
    return Math.floor(date.getTime() / 1000).toString(16) + '0000000000000000';
};
var dateFromObjectId = function (objectId) {
    return new Date(parseInt(objectId.substring(0, 8), 16) * 1000);
};

// Base functions
function printHeader() {
    var logsStatus = getStatus(showLogs);
    var cleanupStatus = getStatus(doCleanup);
    logger(
        '================================================================================================================');
    logger(scriptName + ' ' + version + ' © Sisense | cleanup ' + cleanupStatus + ' | logs ' +
        logsStatus);
    logger(new Date());
    logger(
        '================================================================================================================');
}

function printConfig(config) {
    logger('========== Configuration ==========');
    logger(JSON.stringify(config, undefined, 2));
    logger('====================================');
}

function getIssuesStatus(flag) {
    return flag ? 'fixed' : 'found';
}

function collectStats(key, value) {
    if (typeof collectedStats !== 'undefined') {
        if (collectedStats[key]) {
            collectedStats[key] += value;
        } else {
            collectedStats[key] = value;
        }
    } else {
        collectedStats = {};
        collectedStats[key] = value;
    }
}

function printStats() {
    if (typeof globalRun == 'undefined') {
        logger(scriptName + ' statistics ' + ' © Sisense');
        logger('Total issues ' + getIssuesStatus(doCleanup) + ': ' + filterCount);
        logger(JSON.stringify(collectedStats, undefined, 2));

        logger(
            '================================================================================================================');
    }
}

printHeader();
printConfig(config);

// Global variables
var filter = { instanceType: 'owner' };
var blankFilter = {};

// Functions
function listWidgets(widgets) {
    if (showWidgetInfo) {
        widgets.forEach(function (widget) {
            logger(
                '    widget: ' + widget.title + ' | ' + widget.oid + ' | ' + widget.type + ' | ' +
                widget.instanceType);
        });
    }
}

function onlyUnique(value, index, self) {
    return self.indexOf(value) === index;
}

function restoreWidgetsFromProxy(dash) {
    if (doCleanup) {
        collectStats('restore_from_proxy', 1);
        logger('No widgets in collection, take from proxy instance');
    }
    var proxyWidgets = prismWebDB.getCollection('widgets')
        .find({ dashboardid: dash.oid, instanceType: 'proxy' })
        .toArray();
    listWidgets(proxyWidgets);
    if (doCleanup) {
        createUserWidgets(proxyWidgets, dash);
    }
}

function createUserWidgets(widgets, dash) {

    widgets.forEach(function (widget) {
        delete widget._id;
        widget.instanceType = dash.instanceType;
        widget.owner = dash.owner;
        widget.userId = dash.userId;
        prismWebDB.getCollection('widgets').insertOne(widget);
    });
    if (dash.widgets.length !== widgets.length) {
        logger('Number of widgets on dashboard and in proxy widgets does not match');
        var widgetsArr = prismWebDB.getCollection('widgets')
            .find({ dashboardid: dash.oid, userId: dash.userId, instanceType: dash.instanceType })
            .toArray();
        cleanDashboardWidgets(dash, widgetsArr);
    }
}

function restoreWidgetsFromCollection(dash) {
    collectStats('restore_from_widgets_collection', 1);
    logger('No widgets to keep, take from widgets collection');
}

function findWidgetsDiff(dashWidgets, widgets) {
    var result = {
        diff: [],
        dash: dashWidgets,
        widgets: widgets
    };
    var targetArr = dashWidgets.length > widgets.length ? dashWidgets : widgets;
    var checkArr = dashWidgets.length > widgets.length ? widgets : dashWidgets;
    var oids = targetArr.map(function (w) {
        return parseObjectIdToString(w.oid);
    });
    var cOids = checkArr.map(function (w) {
        return parseObjectIdToString(w.oid);
    });
    //logger(JSON.stringify(oids));
    //logger(JSON.stringify(cOids));
    for (var i = 0; i < targetArr.length; i++) {
        var el = targetArr[i];
        var oid = oids[i];
        var index = cOids.indexOf(oid);
        if (index !== -1) {

        } else {
            result.diff.push(el);
        }
    }

    return result;
}

function cleanDashboardWidgets(dash, widgets) {
    listWidgets(widgets);
    if (doCleanup) {
        updateDashboard(dash, widgets);
    }
}

function updateDashboard(dash, widgets) {
    var result = findWidgetsDiff(dash.widgets, widgets);
    prismWebDB.getCollection('dashboards').updateOne(
        { _id: dash._id },
        { $set: { widgets: [] } },//{ $addToSet: { widgets: result.diff } },
        { upsert: true }
    );
    /*prismWebDB.getCollection('dashboards').updateOne(
        { _id: dash._id },
        { $set: { widgets: widgets } },//{ $addToSet: { widgets: result.diff } },
        { upsert: true }
    );*/
    widgets.forEach(function (widget) {
        var res = prismWebDB.getCollection('dashboards').update(
            { _id: dash._id },
            { $addToSet: { widgets: widget } },
            { upsert: true }
        );
        //print(JSON.stringify(res));
    });
}

// Main script
function fixDashboardWidgets() {

    prismWebDB.getCollection('dashboards').find(blankFilter).forEach(function (dash) {
        var widgetsMap = {};

        if (dash.widgets) {
            dash.widgets.forEach(function (widget) {
                //logger('widget: ' +widget.title + ' | ' + widget.oid + ' | ' + widget.type  )
                if (widgetsMap[widget.oid]) {
                    widgetsMap[widget.oid].push(widget);
                } else {
                    widgetsMap[widget.oid] = [];
                    widgetsMap[widget.oid].push(widget);
                }
            });
            var isDrill = dash.title.indexOf(config.drillPrefix) != -1;
            var widgetsArr = prismWebDB.getCollection('widgets')
                .find({ dashboardid: dash.oid, userId: dash.userId })
                .toArray();

            if (widgetsArr.length !== dash.widgets.length && !isDrill) {
                if (widgetsArr.length > 0) {
                    logger(
                        'dashboard: ' + dash.title + ' | ' + dash.oid + ' | ' + dash.instanceType +
                        ' | ' + dash.userId + ' | dash widgets ' + dash.widgets.length +
                        ' | widgets collection count ' + widgetsArr.length);
                    //logger('Number of widgets does not match');
                    collectStats('widget_count_not_match', 1);
                    //logger('dashbboard widgets: ' + dash.widgets.length);
                    listWidgets(dash.widgets);
                    //logger('widgets from collection: ' + widgetsArr.length);
                    listWidgets(widgetsArr);
                } else {
                    logger(' - dashboard: ' + dash.title + ' | ' + dash.oid + ' | ' +
                        dash.instanceType +
                        ' | ' + dash.userId + ' | dash widgets ' + dash.widgets.length +
                        ' | was not opened yet ');
                    //logger('Number of widgets does not match');
                    //collectStats('widget_count_not_match', 1);
                    //logger('dashbboard widgets: ' + dash.widgets.length);
                    listWidgets(dash.widgets);
                    //logger('widgets from collection: ' + widgetsArr.length);
                    //listWidgets(widgetsArr);
                }

                var widgetsToKeep = [];
                widgetsArr.forEach(function (widget) {
                    if (widgetsMap[widget.oid] && widgetsMap[widget.oid].length >= 1) {
                        var lastDate;
                        widgetsMap[widget.oid].forEach(function (widget) {
                            if (!lastDate) {
                                lastDate = widget.lastUpdated;
                            } else if (lastDate <= widget.lastUpdated) {
                                lastDate = widget.lastUpdated;
                            }
                        });

                        widgetsMap[widget.oid].forEach(function (widgetInner) {
                            if (lastDate === widgetInner.lastUpdated) {
                                widgetsToKeep.push(widget);
                            }
                        });
                    } else {
                        widgetsToKeep.push(widget);
                    }
                });

                if (widgetsToKeep.length === 0) {
                    // TODO temp not create widgets in collection
                    // if (widgetsArr.length === 0) {
                    //     restoreWidgetsFromProxy(dash);
                    // } else {
                    //     restoreWidgetsFromCollection(dash);
                    // }
                } else {
                    if (doCleanup) {
                        logger('Keep widgets: ' + widgetsToKeep.length);
                        cleanDashboardWidgets(dash, widgetsToKeep);
                    }

                }
                //logger('----------------------------------------------------');
            } else {
                //logger('Widget count is equal ' + dash.title + ' | ' + dash.oid + ' | ' + dash.instanceType);
            }

        }

    });
}

fixDashboardWidgets();

