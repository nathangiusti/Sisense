/**
 * Created by yaroslav.korzh
 * Updated 02/05/2019
 */
// General Info
var version = '3.0.0';
var scriptName = 'Dimensions statistics analyzer';

// Configuration
var showLogs = true;
var doCleanup = false;
if (typeof globalCleanup !== 'undefined') {
    // global cleanup
    // comment line below to use local cleanup flag
    doCleanup = globalCleanup;
}
var cleanupStatus = doCleanup ? 'enabled' : 'disabled';
var defferedLogs = true;
var printInFile = false;
var showAllFiters = false;
var showDrill = false;
var userCheck = true;
var logsStatus = showLogs ? 'enabled' : 'disabled';

var config = {
    cleanup: {
        doCleanup: doCleanup
    },
    showDashMessages: false,
    emailPattern: [],
    drillPrefix: '_drill',
    logging: {
        showLogs: showLogs
    }
};

// Common Functions
var checkForHexRegExp = new RegExp('^[0-9a-fA-F]{24}$');
var prismWebDB = db.getSiblingDB('prismWebDB');
var prismConfig = db.getSiblingDB('prismConfig');

function getStatus(flag) {
    return flag ? 'enabled' : 'disabled';
}

function logger(msg) {
    if (showLogs) {
        print(msg);
    }
}

function deferredLogger(str, messages) {

    if (defferedLogs && messages) {
        messages.push(str);
    }

}

function getIssuesStatus(flag) {
    return flag ? 'fixed' : 'found';
}

function collectStats(key, value) {
    if (typeof collectedStats !== 'undefined') {
        if (collectedStats[key]) {
            collectedStats[key] += value;
        } else {
            collectedStats[key] = value;
        }
    } else {
        collectedStats = {};
        collectedStats[key] = value;
    }
}

// *** Basic Functions ***
function isEmptyObject(obj) {
    for (var prop in obj) {
        if (obj.hasOwnProperty(prop)) {
            return false;
        }
    }
    return true;
}

function parseObjectIdToString(id) {
    if (typeof id === 'string') {
        return id;
    } else {
        return id.str;
    }
}

function parseStringToObjectId(id) {
    if (typeof id === 'string') {
        return ObjectId(id);
    } else {
        return id;
    }
}

function validateObjectId(id) {
    var stringId = parseObjectIdToString(id);
    return checkForHexRegExp.test(stringId);
}

var objectIdFromDate = function (date) {
    return Math.floor(date.getTime() / 1000).toString(16) + '0000000000000000';
};
var dateFromObjectId = function (objectId) {
    return new Date(parseInt(objectId.substring(0, 8), 16) * 1000);
};

// Base functions
function printHeader() {
    var logsStatus = getStatus(showLogs);
    var cleanupStatus = getStatus(doCleanup);
    logger(
        '================================================================================================================');
    logger(scriptName + ' ' + version + ' © Sisense | cleanup ' + cleanupStatus + ' | logs ' +
        logsStatus);
    logger(new Date());
    logger('Total widgets' + ' | ' + prismWebDB.getCollection('widgets').count({}));
    logger('Total dashboards' + ' | ' + prismWebDB.getCollection('dashboards').count({}));
    logger(
        '================================================================================================================');
}

function printConfig(config) {
    logger('========== Configuration ==========');
    logger(JSON.stringify(config, undefined, 2));
    logger('====================================');
}

// Global variables
var domains = {};
var defaultProps = {
    'count': 1,
    'metadata': {},
    'filters': {},
    'widget_filters': {},
    'security': {},
    'pulse': {},
    'relations': {},
    'hierarchies': {}
};
var filterCount = 0;
var filtersToCheck = 0;
var dashboardsToCheck = 0;
var drillDashboards = 0;
var dashboardsSkipped = 0;
var totalDashboards = 0;
var datasourcesObj = {};
var blankFilter = {};
var timeout = 300;
var notProxy = { 'instanceType': { '$nin': ['proxy'] } };
var onlyUser = { 'instanceType': { '$nin': ['proxy', 'owner'] } };

// Functions
function collectFilterStats(jaql, type, shouldCheck, datasource) {
    var targetDataSource = jaql.datasource ? jaql.datasource : datasource;
    if (targetDataSource) {
        var targetObj;
        if (datasourcesObj[targetDataSource.title]) {
            targetObj = datasourcesObj[targetDataSource.title][type];
        } else {
            datasourcesObj[targetDataSource.title] = Object.assign({},
                {
                    'count': 1,
                    'metadata': {},
                    'filters': {},
                    'widget_filters': {},
                    'security': {},
                    'pulse': {},
                    'relations': {},
                    'hierarchies': {}
                }
            );
        }
        if (datasourcesObj[targetDataSource.title][type]) {
            targetObj = datasourcesObj[targetDataSource.title][type];
        } else {
            datasourcesObj[targetDataSource.title][type] = {};
            targetObj = datasourcesObj[targetDataSource.title][type];
        }

        if (jaql.dim) {
            if (targetObj[jaql.dim]) {
                targetObj[jaql.dim] += 1;
            } else {
                targetObj[jaql.dim] = 1;
            }
        } else {
            //logger(JSON.stringify(jaql, undefined, 2))
            if (jaql.type === 'measure') {
                Object.keys(jaql.context).forEach(function (key) {
                    //logger(key);
                    var measure = jaql.context[key];
                    //logger('dim: '  + jaql.dim);
                    if (measure.dim) {
                        if (targetObj[measure.dim]) {
                            targetObj[measure.dim] += 1;
                        } else {
                            targetObj[measure.dim] = 1;
                        }
                    }
                });
            }

        }
    } else {
        logger('jaql has no datasource');
    }
}

function printDIMStats(metadataObj, target) {
    var sortable = [];
    for (var dim in metadataObj) {
        sortable.push([dim, metadataObj[dim]]);
    }
    sortable.sort(function (a, b) {
        return b[1] - a[1];
    });

    if (sortable.length == 0) {
        logger(' No data for ' + target);
    } else {
        logger(' Dimension usage stats in ' + target);
        sortable.forEach(function (elem, index, arr) {
            logger('  - ' + elem[0] + ': ' + elem[1]);

        });
    }

}

function printStats() {
    if (typeof globalRun == 'undefined') {
        logger(scriptName + ' statistics ' + ' © Sisense');
        logger('Total issues ' + getIssuesStatus(doCleanup) + ': ' + filterCount);
        logger(JSON.stringify(collectedStats, undefined, 2));

        logger(
            '================================================================================================================');
    }
    logger('Cubes dimensions stats ');
    logger('  ');
    for (var datasource in datasourcesObj) {
        sleep(timeout);
        logger(datasource + ' elasticcube');
        Object.keys(datasourcesObj[datasource]).forEach(function (key) {
            var values = datasourcesObj[datasource][key];
            if (typeof values == 'object') {
                printDIMStats(values, key);
                sleep(timeout);
            }
        });

        var target = 'metadata';
        var targetFilters = 'filters';
        var widgetFilters = 'widget_filters';
        var metadataObj = datasourcesObj[datasource][target];
        var filtersObj = datasourcesObj[datasource][targetFilters];
        var wFiltersObj = datasourcesObj[datasource][widgetFilters];
        logger('        ');
        var cubesCount = prismWebDB.getCollection('elasticubes').count({ title: datasource });
        if (cubesCount > 0) {

            sleep(timeout);
            prismWebDB.getCollection('elasticubes')
                .find({ title: datasource })
                .forEach(function (cube) {
                    if (cube.oid) {
                        logger(' Analyze dims usage by table ');
                        prismWebDB.getCollection('datasets')
                            .find({ elasticube: cube.oid })
                            .forEach(function (set) {
                                logger('  datasets: ' + set.name);
                                var count = prismWebDB.getCollection('datasetTables')
                                    .count({ dataset: set.oid });
                                if (count > 0) {
                                    prismWebDB.getCollection('datasetTables')
                                        .find({ dataset: set.oid })
                                        .forEach(function (table) {
                                            logger('   table: ' + table.name);
                                            table.columns.forEach(function (column) {
                                                //logger('   ' + column.name);
                                                var used = false;

                                                var checkDim = '[' + table.name + '.' +
                                                    column.name +
                                                    ']';
                                                if (metadataObj) {
                                                    if (metadataObj[checkDim]) {
                                                        logger('   + ' + checkDim +
                                                            ' used in widgets: ' +
                                                            metadataObj[checkDim] +
                                                            ' times');
                                                        used = true;
                                                    }
                                                }

                                                if (wFiltersObj) {
                                                    if (filtersObj[checkDim]) {
                                                        logger('   + ' + checkDim + ' used in ' +
                                                            targetFilters + ': ' +
                                                            filtersObj[checkDim] +
                                                            ' times');
                                                        used = true;
                                                    }
                                                }

                                                if (wFiltersObj) {
                                                    if (wFiltersObj[checkDim]) {
                                                        logger('   + ' + checkDim + ' used in ' +
                                                            widgetFilters + ': ' +
                                                            wFiltersObj[checkDim] +
                                                            ' times');
                                                        used = true;
                                                    }
                                                }

                                                if (!used) {
                                                    logger('   ! ' + checkDim + ' not used !');
                                                }
                                            });
                                        });
                                } else {
                                    logger('Cube ' + cube.title +
                                        ' wasn\'t buil yet in web ECM 2.0 - please build and rerun');
                                    logger('To map unused dimensions of the cube');
                                }
                            });
                    }
                });
        } else {
            //logger(' cubes count: ' + cubesCount);
        }

        logger('------------------------------------------------------------------------------');
    }
}

// Main script
printHeader();
printConfig(config);

function analyzeJaql(jaql, type, messages, config, datasource) {
    var showFilter = true;
    var shouldCheck = true;

    if (jaql) {

        collectFilterStats(jaql, type, shouldCheck, datasource);
    }

}

function analyzeFilter(filter, type, messages, config, datasource) {
    if (filter.jaql) {
        var jaql = filter.jaql;
        analyzeJaql(jaql, type, messages, config, datasource);
    }
    if (filter.isCascading) {
        //deferredLogger(' cascading filter levels: ', messages);
        filter.levels.forEach(function (filter) {
            analyzeJaql(filter, type, messages, config, datasource);
        });
    }
}

function analyzeFilters() {

    prismWebDB.getCollection('dashboards').find(blankFilter).forEach(function (dash) {
        var messages = [];
        config.showDashMessages = false;
        var hasFilters = dash.filters && dash.filters.length > 0;
        var hasDefaultFilters = dash.defaultFilters && dash.defaultFilters.length > 0;
        var isDrill = dash.title.indexOf(config.drillPrefix) != -1;

        var showDashInfo = false;//hasFilters || hasDefaultFilters;
        var userInfo = {};

        if (isDrill) {
            drillDashboards += 1;
            if (!showDrill) {
                return;
            } else {

            }
        }

        prismWebDB.getCollection('users').find({ _id: dash.userId }).forEach(function (user) {
            userInfo = user;
        });

        var user = userInfo.email || userInfo.userName || dash.userId;
        if (user) {
            if (user.indexOf) {
                var userDomain = user.split('@')[1];

                var userFilter = config.emailPattern.indexOf(userDomain) != -1;
            }
        }
        if (userCheck) {
            if (userFilter) {
                return;
            } else {
                if (domains[userDomain]) {
                    domains[userDomain] += 1;
                } else {
                    domains[userDomain] = 1;
                }

            }
        }

        if (showDashInfo) {
            deferredLogger('dashboard: ' + dash.title + ' | oid: ' + dash.oid + ' | instance: ' +
                dash.instanceType + ' | user: ' + user, messages);
        }
        if (dash.filters) {
            dash.filters.forEach(function (filter) {
                analyzeFilter(filter, 'filters', messages, config, dash.datasource);
            });
        }
        if (dash.defaultFilters) {
            dash.defaultFilters.forEach(function (filter) {
                analyzeFilter(filter, 'filters', messages, config, dash.datasource);
            });
        }
        //logger(' ');
        prismWebDB.getCollection('widgets')
            .find({ userId: dash.userId, dashboardid: dash.oid })
            .forEach(function (widget) {

                if (widget.metadata.panels) {
                    widget.metadata.panels.forEach(function (panel) {
                        if (panel.name == 'filters' && panel.items.length > 0) {

                            // deferredLogger(
                            //     ' widget: ' + widget.title + ' | _id: ' + widget._id + ' | oid: ' +
                            //     widget.oid + ' has widget filters ', messages);

                            panel.items.forEach(function (filter) {
                                analyzeFilter(filter, 'widget_filters', messages, config,
                                    widget.datasource
                                );
                            });
                        }
                    });
                }

            });
        if (showDashInfo) {
            deferredLogger('----------------------------------------------------', messages);
        }
        if (config.showDashMessages) {
            messages.forEach(function (message) {
                logger(message);
            });
            dashboardsToCheck += 1;
        } else {
            //logger('Skipped ' +messages.length + ' messages on dashboard ' + dash.title);
            dashboardsSkipped += 1;
        }
        totalDashboards += 1;

    });

    //logger(' ');
}

function analyzeHierarchies() {
    db.getCollection('hierarchies').find({}).forEach(function (hierarchy) {
        //logger('hierarchy ' + hierarchy.title);
        var datasource = {};
        db.getCollection('elasticubes').find({ _id: hierarchy.cubeId }).forEach(function (cube) {
            //logger('cube ' + cube.title);
            datasource.title = cube.title;
        });

        hierarchy.levels.forEach(function (level) {
            //logger('level dim ' + level.dim);
            var jaql = { dim: level.dim };
            collectFilterStats(jaql, 'hierarchies', true, datasource);
        });
        //logger(' ');
    });
    //logger(' ');
}

function analyzeRelations() {
    db.getCollection('elasticubeRelations').find({}).forEach(function (relation) {
        //logger('elasticube relation  ' + relation.elasticube);
        //logger(' ');
        var datasource = {};

        prismWebDB.getCollection('elasticubes')
            .find({ oid: relation.elasticube })
            .forEach(function (cube) {
                //logger(cube.title + ' '+cube.server );
                datasource.title = cube.title;
            });
        relation.columns.forEach(function (column) {
            //logger(column.dataset + ' '+column.table+ ' '+column.column)
            var count = prismWebDB.getCollection('datasetTables')
                .count({ oid: column.table });
            if (count > 0) {
                prismWebDB.getCollection('datasetTables')
                    .find({ oid: column.table })
                    .forEach(function (table) {
                        //logger('Table: ' + table.name);
                        table.columns.forEach(function (datasetColumn) {
                            if (datasetColumn.oid == column.column) {
                                //logger('   Column ' + datasetColumn.name  +' is used in relations');

                                var dim = '[' + table.name + '.' + datasetColumn.name + ']';
                                var jaql = { dim: dim };
                                collectFilterStats(jaql, 'relations', true, datasource);
                            }
                        });
                    });
            } else {
                logger('Cube  wasn\'t buil yet in web ECM 2.0 - please build and rerun');
                logger('To map unused dimensions of the cube');
            }
        });
        //logger(' ');
    });
    //logger(' ');
}

function analyzeSecurity() {
    db.getCollection('dataContext').find({}).forEach(function (security) {
        var datasource = {};
        var dim = '[' + security.table + '.' + security.column + ']';
        if (!security.table || !security.column || !security.cubeId) {
            logger('security rule for ' + dim + ' ' + security.cubeId);
            logger(JSON.stringify(security, undefined, 2));
        }
        var cubeCount = db.getCollection('elasticubes').count({ _id: security.cubeId });
        if (cubeCount == 0) {
            //logger(' - Cube for this rule doesnt exist');
        } else {
            db.getCollection('elasticubes').find({ _id: security.cubeId }).forEach(function (cube) {
                //logger('cube ' + cube.title);
                datasource.title = cube.title;
            });
        }
        var jaql = { dim: dim };
        collectFilterStats(jaql, 'security', true, datasource);

    });
    //logger(' ');
}

function analyzePulse() {
    db.getCollection('alerts').find({}).forEach(function (alert) {
        //logger('pulse' + ' ' + alert.name + ' ' + alert.type + ' ' + alert.category);
        var messages = [];
        if (alert.type === 'kpi') {
            db.getCollection('kpi').find({ _id: alert.context.kpi }).forEach(function (kpi) {

                Object.keys(kpi.metadata).forEach(function (key) {

                    var values = kpi.metadata[key];
                    values.forEach(function (val) {
                        if (val.jaql) {
                            analyzeJaql(val.jaql, 'pulse', messages, config, kpi.datasource);
                        }
                    });
                });
            });
        } else {
            logger('not kpi alert');
            logger('pulse' + ' ' + alert._id + ' ' + alert.name + ' ' + alert.type + ' ' +
                alert.category);
        }

    });
    //logger(' ');
}

function analyzeMetadata() {
    prismWebDB.getCollection('widgets').find({}).forEach(function (widget) {
        //logger('widget: ' + widget.datasource.title + ' | ' + widget.datasource.address);
        if (widget.datasource) {
            if (datasourcesObj[widget.datasource.title]) {
                datasourcesObj[widget.datasource.title]['count'] += 1;
            } else {
                datasourcesObj[widget.datasource.title] = Object.assign({},
                    {
                        'count': 1,
                        'metadata': {},
                        'filters': {},
                        'widget_filters': {},
                        'security': {},
                        'pulse': {},
                        'relations': {},
                        'hierarchies': {}
                    }
                );//defaultProps
            }

            var metadataObj = datasourcesObj[widget.datasource.title]['metadata'];
            //collectStats('dim_stats', 1);
            widget.metadata.panels.forEach(function (panel) {
                //logger('widget: ' + widget.datasource.title + ' | ' + widget.datasource.address);

                collectStats('dim_stats', 1);
                panel.items.forEach(function (item) {
                    //logger('dim: '  + item.jaql.dim);
                    collectFilterStats(item.jaql, 'metadata', true, widget.datasource);
                    // if (item.jaql.dim) {
                    //     if (metadataObj[item.jaql.dim]) {
                    //         metadataObj[item.jaql.dim] += 1;
                    //     } else {
                    //         metadataObj[item.jaql.dim] = 1;
                    //     }
                    // }
                    // else {
                    //     //logger(JSON.stringify(item.jaql, undefined, 2))
                    //     if (item.jaql.type === 'measure') {
                    //         Object.keys(item.jaql.context).forEach(function (key) {
                    //             //logger(key);
                    //             var measure = item.jaql.context[key];
                    //             //logger('dim: '  + item.jaql.dim);
                    //             if (measure.dim) {
                    //                 if (metadataObj[measure.dim]) {
                    //                     metadataObj[measure.dim] += 1;
                    //                 } else {
                    //                     metadataObj[measure.dim] = 1;
                    //                 }
                    //             }
                    //         });
                    //     }
                    //
                    // }
                });
            });

        } else {
            logger('widget: ' + widget.title + ' ' + widget._id + '  has no datasource ');
        }
    });
    //logger(' ');
}

logger('analyze Metadata');
analyzeMetadata();
logger('analyze Filters');
analyzeFilters();
logger('analyze Hierarchies');
analyzeHierarchies();
logger('analyze Security');
analyzeSecurity();
logger('analyze Pulse');
analyzePulse();
logger('analyze Relations');
analyzeRelations();

if (typeof loadedFromAnotherScript !== 'undefined') {
    printStats();
} else {
    printStats();
}

//logger(JSON.stringify(datasourcesObj, undefined, 2));
//logger('--------------------------');

