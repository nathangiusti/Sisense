﻿/**
 * Created by yaroslav.korzh
 * Updated 02/05/2019
 */
// General Info
var version = '3.0.0';
var scriptName = 'Dashboards validate';

// Configuration
var showLogs = true;
var doCleanup = false;
if (typeof globalCleanup !== 'undefined') {
    // global cleanup
    // comment line below to use local cleanup flag
    doCleanup = globalCleanup;
}

var config = {
    cleanup: {
        doCleanup: doCleanup
    },
    logging: {
        showLogs: showLogs
    },
    drillPrefix: '_drill'
};

// Common Functions
var checkForHexRegExp = new RegExp('^[0-9a-fA-F]{24}$');
var prismWebDB = db.getSiblingDB('prismWebDB');
var prismConfig = db.getSiblingDB('prismConfig');

function getStatus(flag) {
    return flag ? 'enabled' : 'disabled';
}

function logger(msg) {
    if (showLogs) {
        print(msg);
    }
}

// *** Basic Functions ***
function isEmptyObject(obj) {
    for (var prop in obj) {
        if (obj.hasOwnProperty(prop)) {
            return false;
        }
    }
    return true;
}

function parseObjectIdToString(id) {
    if (typeof id === 'string') {
        return id;
    } else {
        return id.str;
    }
}

function parseStringToObjectId(id) {
    if (typeof id === 'string') {
        return ObjectId(id);
    } else if (typeof id == 'undefined') {
        return null;
    } else {
        return id;
    }
}

function validateObjectId(id) {
    var stringId = parseObjectIdToString(id);
    return checkForHexRegExp.test(stringId);
}

var objectIdFromDate = function (date) {
    return Math.floor(date.getTime() / 1000).toString(16) + '0000000000000000';
};
var dateFromObjectId = function (objectId) {
    return new Date(parseInt(objectId.substring(0, 8), 16) * 1000);
};

// Base functions
function printHeader() {
    var logsStatus = getStatus(showLogs);
    var cleanupStatus = getStatus(doCleanup);
    print(
        '================================================================================================================');
    print(scriptName + ' ' + version + ' © Sisense | cleanup ' + cleanupStatus + ' | logs ' +
        logsStatus);
    print(new Date());
    print(
        '================================================================================================================');
}

function getIssuesStatus(flag) {
    return flag ? 'fixed' : 'found';
}

function collectStats(key, value) {
    if (typeof collectedStats !== 'undefined') {
        if (collectedStats[key]) {
            collectedStats[key] += value;
        } else {
            collectedStats[key] = value;
        }
    } else {
        collectedStats = {};
        collectedStats[key] = value;
    }
}

function printStats() {
    if (typeof globalRun == 'undefined') {
        logger(scriptName + ' statistics ' + ' © Sisense');
        logger('Total issues ' + getIssuesStatus(doCleanup) + ': ' + filterCount);
        print(JSON.stringify(collectedStats, undefined, 2));

        logger(
            '================================================================================================================');
    }
}

function printConfig(config) {
    print('========== Configuration ==========');
    print(JSON.stringify(config, undefined, 2));
    print('====================================');
}

printHeader();
printConfig(config);

// Global variables
var invalidUserCount = 0;
var ghostWidgetCount = 0;
var bulk = prismWebDB.dashboards.initializeUnorderedBulkOp();
// Functions

// *** Group Validation Functions ***
function isGroupIdExists(id) {
    var groupId = parseStringToObjectId(id);
    // If we found a group with the given id
    var groupExists = prismWebDB.groups.find({ _id: groupId }).limit(1).hasNext();
    return groupExists;
}

function validateGroupId(id) {
    return (validateObjectId(id) && isGroupIdExists(id));
}

//  *** Folder Validation Functions ***
function isFolderIdExists(id) {
    var folderOid = parseStringToObjectId(id);
    // If we found a group with the given id
    var folderExists = prismWebDB.tags.find({ oid: folderOid }).limit(1).hasNext();
    return folderExists;
}

function validateFolderId(id) {
    return (validateObjectId(id) && isFolderIdExists(id));
}

// *** Jobs Validation Functions ***
function validateSubscriptionJob(job) {
    var dashboardId = parseStringToObjectId(job.dashboardId);
    var dashCount = prismWebDB.dashboards.count({ oid: dashboardId });
    var widgetCount = prismWebDB.widgets.count({ dashboardid: dashboardId });
    // If there are no dashboards and no widgets (meaning that the dasboard was deleted)
    return !(dashCount == 0 && widgetCount == 0);
}

// *** Dashboards Validation Functions ***
function validateSharedDashboard(dashboard) {
    var objectOid = parseStringToObjectId(dashboard.oid);
    return prismWebDB.dashboards.find({ oid: objectOid, instanceType: 'owner' }).limit(1).hasNext();
}

function validateParentFolder(dashboard) {
    if (dashboard.parentFolder && !!dashboard.parentFolder) {
        return validateFolderId(dashboard.parentFolder);
    } else {
        return true;
    }
}

function validateUser(dashboard) {
    var objectOid = parseStringToObjectId(dashboard.userId);
    if (dashboard.instanceType === 'proxy') {
        return true;
    }
    if (typeof dashboard.userId === 'string') {
        print('User Id for ' + dashboard.title + ' (_id): ' + dashboard._id + ' is a string ');
        if (doCleanup) {
            print(
                'Casting UserId to ObjectId ' + dashboard.title + ' (_id): ' + dashboard._id + ' ');
            prismWebDB.dashboards.update(
                {
                    oid: dashboard.oid, userId: dashboard.userId
                },
                {
                    $set: {
                        userId: objectOid
                    }
                }
            );
        }
    }

    return prismWebDB.users.find({ _id: objectOid }).limit(1).hasNext();
}

// This code was updated in 06.10.16 by Alon Berkman (It might not be relevant in later versions than 6.5)
function clearLayoutFromGhostWidget(dashboard, ghostWidget) {
    // removing element
    ghostWidget.subcell.elements.splice(ghostWidget.elementidx, 1);
    if (ghostWidget.subcell.elements.length == 0) {
        // removing subcell
        ghostWidget.cell.subcells.splice(ghostWidget.subcellidx, 1);
        if (ghostWidget.cell.subcells.length == 0) {
            // removing cell
            ghostWidget.col.cells.splice(ghostWidget.cellidx, 1);
            /* decided to leave the column empty when there are no cells */
            //if (ghostWidget.col.cells.length == 0) {
            // remove column
            //ghostWidget.columns.splice(ghostWidget.colidx, 1);
            //}
        }
    }

    if (doCleanup) {
        print('Cleaning ghost widget from ' + dashboard.title + ' (_id): ' + dashboard._id +
            ' (oid): ' + dashboard.oid + ' (userId): ' + dashboard.userId + ' ');
        prismWebDB.dashboards.update(
            {
                oid: dashboard.oid, userId: dashboard.userId
            },
            {
                $set: {
                    layout: dashboard.layout
                }
            }
        );
    }
}

function validateDashboardLayout(dashboard) {

    var isLayoutValid = true;
    var isDrill = dashboard.title.indexOf(config.drillPrefix) != -1;

    if (dashboard.layout && !isDrill) {
        // The layout is validate if there are no columns
        if (!dashboard.layout.columns) {
            return true;
        }

        var dashboardWidgets = [];
        var ownerWidgets = [];

        prismWebDB.widgets.find({ dashboardid: dashboard.oid, userId: dashboard.userId })
            .forEach(function (widget) {
                dashboardWidgets.push(parseObjectIdToString(widget.oid));
            });
        prismWebDB.widgets.find({ dashboardid: dashboard.oid, instanceType: 'owner' })
            .forEach(function (widget) {
                ownerWidgets.push(parseObjectIdToString(widget.oid));
            });
        var notOpened = false;
        for (var colidx = 0; colidx < dashboard.layout.columns.length; colidx++) {
            var col = dashboard.layout.columns[colidx];
            if (col.cells && col.cells.length > 0) {
                for (var cellidx = 0; cellidx < col.cells.length; cellidx++) {
                    var cell = col.cells[cellidx];
                    if (cell.subcells && cell.subcells.length > 0) {
                        for (var subcellidx = 0; subcellidx < cell.subcells.length; subcellidx++) {
                            var subcell = cell.subcells[subcellidx];
                            if (subcell.elements && subcell.elements.length > 0) {
                                for (var elementidx = 0; elementidx <
                                subcell.elements.length; elementidx++
                                ) {
                                    var element = subcell.elements[elementidx];
                                    if (dashboardWidgets.indexOf(element.widgetid) === -1 &&
                                        ownerWidgets.indexOf(element.widgetid) !== -1) {
                                        notOpened = true;
                                    }

                                    // If the widget exists on the layout but not for real
                                    if (dashboardWidgets.indexOf(element.widgetid) === -1 &&
                                        ownerWidgets.indexOf(element.widgetid) === -1) {
                                        isLayoutValid = false;

                                        var ghostWidget = {
                                            col: col,
                                            colidx: colidx,
                                            cell: cell,
                                            cellidx: cellidx,
                                            subcell: subcell,
                                            subcellidx: subcellidx,
                                            element: element,
                                            elementidx: elementidx
                                        };
                                        logger('Ghost widget ' + element.widgetid + '  at: col ' +
                                            colidx + ' cell ' + cellidx + ' subcell ' + subcellidx +
                                            ' elem ' + elementidx + ' ');
                                        clearLayoutFromGhostWidget(dashboard, ghostWidget);
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        if (notOpened) {
            logger('Dashboard ' + dashboard.oid + ' was not opened by ' + dashboard.userId +
                ' yet, widgets not created');
        }
    } else if (isDrill) {

    } else {
        isLayoutValid = false;
        print('Dashboard ' + dashboard.title + ' (_id): ' + dashboard._id + ' has no layout');

        if (doCleanup) {
            print('Add layout to ' + dashboard.title + ' (_id): ' + dashboard._id + ' Dashboard ');
            prismWebDB.dashboards.update(
                { _id: dashboard._id },
                { $set: { 'layout': {} } },
                { multi: true }
            );
        }
    }

    return (isLayoutValid);
}

function validateDashboard(dashboard) {
    var isValid = true;

    if (!validateObjectId(dashboard._id)) {
        isValid = false;
        collectStats('dashboard_invalid_id', 1);
        print('Dashboard (_id): ' + dashboard._id + ' has invalid dashboard id');
    }

    if (!validateObjectId(dashboard.oid)) {
        isValid = false;
        collectStats('dashboard_invalid_oid', 1);
        print('Dashboard (_id): ' + dashboard._id + ' has invalid dashboard oid: ' + dashboard.oid);
    }

    if (!validateParentFolder(dashboard)) {
        isValid = false;
        print('Dashboard (_id): ' + dashboard._id + ' has invalid parent folder: ' +
            dashboard.parentFolder);
        collectStats('dashboard_invalid_parent_folder', 1);
        if (doCleanup) {
            print('Dashboard (_id): ' + dashboard._id + ' removing parent folder: ' +
                dashboard.parentFolder);
            prismWebDB.dashboards.update(
                { _id: dashboard._id },
                { $unset: { 'parentFolder': '' } },
                { multi: true }
            );
        }
    }

    if (!validateUser(dashboard)) {
        isValid = false;
        print('Dashboard (_id): ' + dashboard._id + ' (title): ' + dashboard.title +
            ' has invalid user: ' + dashboard.userId);
        collectStats('invalid_dashboard_user', 1);
        invalidUserCount += 1;
        if (doCleanup) {
            // remove dashboard
            print('Dashboard (_id): ' + dashboard._id + ' is removed due to invalid user: ' +
                dashboard.userId);
            var result = prismWebDB.getCollection('dashboards')
                .remove({ _id: dashboard._id, userId: dashboard.userId });
            print('Removed dashboards: ' + result.nRemoved); // JSON.stringify(result, undefined, 2)
            var resultWidgets = prismWebDB.getCollection('widgets')
                .remove({ dashboardid: dashboard.oid, userId: dashboard.userId });
            print('Removed widgets: ' + resultWidgets.nRemoved); // JSON.stringify(result, undefined, 2)
        }
    }

    // If it's a shared dashboard (shared to the owner and to another one)
    if (dashboard.instanceType === 'proxy' || dashboard.instanceType === 'user') {
        if (!validateSharedDashboard(dashboard)) {
            isValid = false;
            print('Dashboard (oid): ' + dashboard.oid +
                ' is shared and does not have an owner instance');
            collectStats('no_owner_dashboard', 1);
            var newDash = {};
            Object.keys(dashboard).forEach(function (item) {
                var val = dashboard[item];
                newDash[item] = val;
            });

            if (doCleanup) {
                delete newDash._id;
                newDash.instanceType = 'owner';
                newDash.userId = dashboard.owner;
                prismWebDB.getCollection('dashboards').insert(newDash);
            }

        }
    }

    if (dashboard.instanceType !== 'proxy' && !validateDashboardLayout(dashboard)) {
        isValid = false;
        ghostWidgetCount += 1;
        collectStats('ghost_widgets', 1);
        print('Dashboard (_id): ' + dashboard._id + ' (oid): ' + dashboard.oid + ' (title): ' +
            dashboard.title + ' of user ' + dashboard.userId + ' has a GHOST widget');
    }

    if (!isValid) {
        //print("db.getSiblingDB('prismWebDB').dashboards.find({_id: ObjectId('" + dashboard._id + "')});");
    }
}

function validateAllDashboards() {
    print('Validating all dashboards...');

    var bulkSize = 10;
    var dashCount = prismWebDB.dashboards.count();

    print('Total dashboards', dashCount);

    for (var i = 0; i < dashCount; i = i + bulkSize) {
        var bulkDashboards = prismWebDB.dashboards
            .find({})
            .skip(i).limit(bulkSize);

        bulkDashboards.forEach(function (dashboard) {
            validateDashboard(dashboard);
        });
    }
    if (invalidUserCount > 0) {
        logger('Dashboards with broken users: ' + invalidUserCount + ' copies');
    }
    if (ghostWidgetCount > 0) {
        logger('Dashboards with ghost widgets: ' + ghostWidgetCount + ' copies');
    }

    print('Valiadting all dashboards has ended.');
}

// Main script

validateAllDashboards();

printStats();