var version = '3.0.0';
var doCleanup = false;
if (typeof globalCleanup !== 'undefined') {
    // global cleanup
    // comment line below to use local cleanup flag
    doCleanup = globalCleanup;
}

var cleanupStatus = doCleanup ? 'enabled' : 'disabled';
var showLogs = true;
var defferedLogs = true;
var printInFile = false;
var showAllFiters = false;
var showDrill = false;
var userCheck = true;
var logsStatus = showLogs ? 'enabled' : 'disabled';

var config = {
    showDashMessages: false,
    emailPattern: ['oversightsystems.com', 'oversight-solutions.com'],
    drillPrefix: '_drill'
};

// Common Functions
var checkForHexRegExp = new RegExp('^[0-9a-fA-F]{24}$');
var prismWebDB = db.getSiblingDB('prismWebDB');
var prismConfig = db.getSiblingDB('prismConfig');

function logger(str) {
    if (showLogs) {
        print(str);
    }

    if (printInFile) {
        printjson(str);
    }
}

function deferredLogger(str, messages) {

    if (defferedLogs && messages) {
        messages.push(str);
    }

}

function printHeader() {
    print('Filter analyzer ' + version + ' © Sisense');
    print(
        '================================================================================================================');
}

function getStatus(flag) {
    return flag ? 'enabled' : 'disabled';
}

function getIssuesStatus(flag) {
    return flag ? 'fixed' : 'found';
}

function collectStats(key, value) {
    if (typeof collectedStats !== 'undefined') {
        if (collectedStats[key]) {
            collectedStats[key] += value;
        } else {
            collectedStats[key] = value;
        }
    } else {
        collectedStats = {};
        collectedStats[key] = value;
    }
}

function printStats() {
    if (typeof globalRun == 'undefined') {
        logger(scriptName + ' statistics ' + ' © Sisense');
        logger('Total issues ' + getIssuesStatus(doCleanup) + ': ' + filterCount);
        print(JSON.stringify(collectedStats, undefined, 2));

        logger(
            '================================================================================================================');
    }
}

function collectFilterStats(jaql, type, shouldCheck) {
    var statsByType = filterStats[type];
    if (!statsByType) {
        filterStats[type] = {
            datatype: {},
            collapsed: {},
            check: {
                yes: 0,
                no: 0
            },
            total: 0
        };
        statsByType = filterStats[type];
    }
    var statByData;
    if (jaql.datatype) {
        statByData = statsByType['datatype'];
        if (statByData) {
            if (statByData[jaql.datatype]) {
                statByData[jaql.datatype] += 1;
            } else {
                statByData[jaql.datatype] = 1;
            }
        }
    }
    if (jaql.hasOwnProperty('collapsed')) {
        statByData = statsByType['collapsed'];
        if (statByData) {
            if (statByData[jaql.collapsed]) {
                statByData[jaql.collapsed] += 1;
            } else {
                statByData[jaql.collapsed] = 1;
            }
        }
    }
    if (shouldCheck) {
        statsByType.check.yes += 1;
    } else {
        statsByType.check.no += 1;
    }
    statsByType.total += 1;
}

function printFilterStats() {
    var value = (filtersToCheck / filterCount).toFixed(3);
    var checkPercentage = value * 100;
    var dashValue = (dashboardsToCheck / totalDashboards).toFixed(3);
    var dashPercentage = dashValue * 100;
    logger('Filter statistics ' + ' © Sisense');
    logger('Total filters: ' + filterCount);
    logger('To check filters: ' + filtersToCheck);
    logger('Percentage of filters to verify: ' + checkPercentage + '%');
    logger('----------------------------------------------------');
    logger('Total analyzed dashboards: ' + totalDashboards);
    logger('To check dashboards: ' + dashboardsToCheck);
    logger('Drill dashboards: ' + drillDashboards);
    logger('Skipped ( Not relevant ) dashboards: ' + dashboardsSkipped);
    logger('Percentage of dashboards to verify: ' + dashPercentage + '%');
    logger('----------------------------------------------------');
    logger('Average filters per dashboard: ' + (filterCount / totalDashboards).toFixed(3));
    logger('Average filters to check per dashboard to check: ' +
        (filtersToCheck / dashboardsToCheck).toFixed(3));
    logger('----------------------------------------------------');
    logger('User dashboard stats per domain');
    logger(JSON.stringify(domains, undefined, 2));
    Object.keys(filterStats).forEach(function (item) {
        var statsByType = filterStats[item];
        logger('Filter type: ' + item);
        Object.keys(statsByType).forEach(function (item) {
            var statsItem = statsByType[item];

            if (typeof statsItem == 'object') {
                logger(' ' + item);
                Object.keys(statsItem).forEach(function (item) {
                    var statsElem = statsItem[item];
                    logger('  ' + item + ': ' + statsElem);
                });
            } else {
                logger(' ' + item + ': ' + statsItem);
            }
            if (item == 'total') {
                var value = (statsByType['check'].yes / statsItem).toFixed(3);
                var checkPercentage = value * 100;
                logger(' percentage of filters to verify: ' + checkPercentage + '%');
            }
            logger(' -------------------');
        });
        logger('----------------------------------------------------');
    });
    logger(
        '================================================================================================================');
}

var domains = {};
var filterStats = {};
var filterCount = 0;
var filtersToCheck = 0;
var dashboardsToCheck = 0;
var drillDashboards = 0;
var dashboardsSkipped = 0;
var totalDashboards = 0;
var blankFilter = {};
var notProxy = { 'instanceType': { '$nin': ['proxy'] } };
var onlyUser = { 'instanceType': { '$nin': ['proxy', 'owner'] } };
printHeader();

function analyzeJaql(jaql, type, messages, config) {
    var showFilter = true;
    var shouldCheck = true;

    if (jaql) {
        if (jaql.filter) {
            filterCount += 1;
            var values = jaql.filter.members;
            if (jaql.filter.exclude) {
                var hasExcludes = true;
                var exValues = jaql.filter.exclude.members;
            }
            if (jaql.datatype == 'datetime') {
                showFilter = false;
                shouldCheck = false;
            }
            if (!values && jaql.filter.all) {
                values = 'Include All';
                showFilter = false;
                shouldCheck = false;
            }
            if (!jaql.collapsed) {
                showFilter = false;
                shouldCheck = false;
            }

            if (showAllFiters) {
                showFilter = showAllFiters;
            }

            if (showFilter) {
                deferredLogger(
                    '  filter ' + type + ': ' + jaql.title + ' | data type: ' + jaql.datatype +
                    ' | collapsed: ' + jaql.collapsed, messages);
                var valuesMsg = '';
                if (values) {
                    valuesMsg += '    values: ' + JSON.stringify(values);
                }
                if (hasExcludes) {
                    valuesMsg += '    exclude values: ' + JSON.stringify(exValues);
                }
                deferredLogger(valuesMsg, messages);
            } else {

            }
            if (shouldCheck) {
                filtersToCheck += 1;
                config.showDashMessages = true;
            }
            collectFilterStats(jaql, type, shouldCheck);
        }
        //print('show messages ' + config.showDashMessages);
    }

}

function analyzeFilter(filter, type, messages, config) {
    if (filter.jaql) {
        var jaql = filter.jaql;
        analyzeJaql(jaql, type, messages, config);
    }
    if (filter.isCascading) {
        deferredLogger(' cascading filter levels: ', messages);
        filter.levels.forEach(function (filter) {
            analyzeJaql(filter, 'cascading', messages, config);
        });
    }
}

function analyzeFilters() {

    prismWebDB.getCollection('dashboards').find(blankFilter).forEach(function (dash) {
        var messages = [];
        config.showDashMessages = false;
        var hasFilters = dash.filters && dash.filters.length > 0;
        var hasDefaultFilters = dash.defaultFilters && dash.defaultFilters.length > 0;
        var isDrill = dash.title.indexOf(config.drillPrefix) != -1;

        var showDashInfo = hasFilters || hasDefaultFilters;
        var userInfo = {};

        if (isDrill) {
            drillDashboards += 1;
            if (!showDrill) {
                return;
            } else {

            }
        }

        prismWebDB.getCollection('users').find({ _id: dash.userId }).forEach(function (user) {
            userInfo = user;
        });

        var user = userInfo.email || userInfo.userName || dash.userId;
        if (user) {
            if (user.indexOf) {
                var userDomain = user.split('@')[1];

                var userFilter = config.emailPattern.indexOf(userDomain) != -1;
            }
        }
        if (userCheck) {
            if (userFilter) {
                return;
            } else {
                if (domains[userDomain]) {
                    domains[userDomain] += 1;
                } else {
                    domains[userDomain] = 1;
                }

            }
        }

        if (showDashInfo) {
            deferredLogger('dashboard: ' + dash.title + ' | oid: ' + dash.oid + ' | instance: ' +
                dash.instanceType + ' | user: ' + user, messages);
        }
        if (dash.filters) {
            dash.filters.forEach(function (filter) {
                analyzeFilter(filter, 'dashboard', messages, config);
            });
        }
        if (dash.defaultFilters) {
            dash.defaultFilters.forEach(function (filter) {
                analyzeFilter(filter, 'default', messages, config);
            });
        }
        //logger('');
        prismWebDB.getCollection('widgets')
            .find({ userId: dash.userId, dashboardid: dash.oid })
            .forEach(function (widget) {

                if (widget.metadata.panels) {
                    widget.metadata.panels.forEach(function (panel) {
                        if (panel.name == 'filters' && panel.items.length > 0) {

                            deferredLogger(
                                ' widget: ' + widget.title + ' | _id: ' + widget._id + ' | oid: ' +
                                widget.oid + ' has widget filters ', messages);

                            panel.items.forEach(function (filter) {
                                analyzeFilter(filter, 'widget', messages, config);
                            });
                        }
                    });
                }

            });
        if (showDashInfo) {
            deferredLogger('----------------------------------------------------', messages);
        }
        if (config.showDashMessages) {
            messages.forEach(function (message) {
                logger(message);
            });
            dashboardsToCheck += 1;
        } else {
            //logger('Skipped ' +messages.length + ' messages on dashboard ' + dash.title);
            dashboardsSkipped += 1;
        }
        totalDashboards += 1;

    });

    logger('');
    logger(
        '================================================================================================================');
}

analyzeFilters();
printFilterStats();