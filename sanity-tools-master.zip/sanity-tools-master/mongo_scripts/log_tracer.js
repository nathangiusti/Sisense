// General Info
var version = '3.0.0';
var monitor = db.getSiblingDB('monitor');
var filter_time = {
    timestamp: {
        $gte: ISODate('2019-04-04 00:00:00.745Z'),
        $lt: ISODate('2019-04-04 12:00:00.745Z')
    }
};
var filter_request = {
    'meta.method': 'POST'
};
var filter_blank = {};

monitor.getCollection('trace').find(filter_time).forEach(function (logObject) {
    print(logObject.timestamp + ' ' + logObject.level + ' ' + logObject.message);
    print('--------------------------');
    var logStr = '';
    var logKeys = '';
    Object.keys(logObject.meta).forEach(function (key, value) {
        var item = logObject.meta[key];
        logKeys += key + ' ';
        logStr += item + ' ';
    });
    print(logKeys);
    print(logStr);
    print('=============================');
});