﻿/**
 * Created by yaroslav.korzh
 * Updated 02/05/2019
 */
// General Info
var version = '3.0.0';
var scriptName = 'Unused cubes cleaner';

// Configuration
var showLogs = true;
var doCleanup = false;
if (typeof globalCleanup !== 'undefined') {
    // global cleanup
    // comment line below to use local cleanup flag
    doCleanup = globalCleanup;
}

var config = {
    cleanup: {
        doCleanup: doCleanup
    },
    logging: {
        showLogs: showLogs
    }
};

// Common Functions
var checkForHexRegExp = new RegExp('^[0-9a-fA-F]{24}$');
var prismWebDB = db.getSiblingDB('prismWebDB');
var prismConfig = db.getSiblingDB('prismConfig');

function getStatus(flag) {
    return flag ? 'enabled' : 'disabled';
}

function logger(msg) {
    if (showLogs) {
        print(msg);
    }
}

function getIssuesStatus(flag) {
    return flag ? 'fixed' : 'found';
}

function collectStats(key, value) {
    if (typeof collectedStats !== 'undefined') {
        if (collectedStats[key]) {
            collectedStats[key] += value;
        } else {
            collectedStats[key] = value;
        }
    } else {
        collectedStats = {};
        collectedStats[key] = value;
    }
}

function printStats() {
    if (typeof globalRun == 'undefined') {
        logger(scriptName + ' statistics ' + ' © Sisense');
        logger('Total issues ' + getIssuesStatus(doCleanup) + ': ' + filterCount);
        print(JSON.stringify(collectedStats, undefined, 2));

        logger(
            '================================================================================================================');
    }
}

// *** Basic Functions ***
function isEmptyObject(obj) {
    for (var prop in obj) {
        if (obj.hasOwnProperty(prop)) {
            return false;
        }
    }
    return true;
}

function parseObjectIdToString(id) {
    if (typeof id === 'string') {
        return id;
    } else {
        return id.str;
    }
}

function parseStringToObjectId(id) {
    if (typeof id === 'string') {
        return ObjectId(id);
    } else {
        return id;
    }
}

function validateObjectId(id) {
    var stringId = parseObjectIdToString(id);
    return checkForHexRegExp.test(stringId);
}

var objectIdFromDate = function (date) {
    return Math.floor(date.getTime() / 1000).toString(16) + '0000000000000000';
};
var dateFromObjectId = function (objectId) {
    return new Date(parseInt(objectId.substring(0, 8), 16) * 1000);
};

// Base functions
function printHeader() {
    var logsStatus = getStatus(showLogs);
    var cleanupStatus = getStatus(doCleanup);
    print(
        '================================================================================================================');
    print(scriptName + ' ' + version + ' © Sisense | cleanup ' + cleanupStatus + ' | logs ' +
        logsStatus);
    print(new Date());
    print(
        '================================================================================================================');
}

function printConfig(config) {
    print('========== Configuration ==========');
    print(JSON.stringify(config, undefined, 2));
    print('====================================');
}

printHeader();
printConfig(config);

// Global variables
var serversObj = {};
var datasourcesObj = {};
// Functions

// Main script
logger('Total widgets' + ' | ' + prismWebDB.getCollection('widgets').count({}));
prismWebDB.getCollection('widgets').find({}).forEach(function (widget) {
    //logger('widget: ' + widget.datasource.title + ' | ' + widget.datasource.address);
    if (widget.datasource) {
        if (datasourcesObj[widget.datasource.title]) {
            datasourcesObj[widget.datasource.title] += 1;
        } else {
            datasourcesObj[widget.datasource.title] = 1;
        }
    }

});
logger('Total dashboards' + ' | ' + prismWebDB.getCollection('dashboards').count({}));
print('====================================');
prismWebDB.getCollection('dashboards').find({}).forEach(function (dash) {
    //logger('widget: ' + widget.datasource.title + ' | ' + widget.datasource.address);
    if (dash.datasource) {
        if (datasourcesObj[dash.datasource.title]) {
            datasourcesObj[dash.datasource.title] += 1;
        } else {
            datasourcesObj[dash.datasource.title] = 1;
        }
    }

});
logger('--------------------------');
logger('Used cubes: ' + Object.keys(datasourcesObj).length);
prismWebDB.getCollection('elasticubes')
    .find({ title: { $in: Object.keys(datasourcesObj) } })
    .forEach(function (elasticube) {
        var count = datasourcesObj[elasticube.title];
        logger(
            'elasticube: ' + elasticube.title + ' | ' + elasticube.server + ' | ' + elasticube._id +
            ' | ' + count);
    });
logger('--------------------------');
var unusedCubesCount = prismWebDB.getCollection('elasticubes')
    .count({ title: { $nin: Object.keys(datasourcesObj) } });
logger('Unused cubes: ' + unusedCubesCount);
collectStats('unused_cubes', unusedCubesCount);
prismWebDB.getCollection('elasticubes')
    .find({ title: { $nin: Object.keys(datasourcesObj) } })
    .forEach(function (elasticube) {
        logger(
            'elasticube: ' + elasticube.title + ' | ' + elasticube.server + ' | ' + elasticube._id);
    });

if (doCleanup) {
    // todo temp commented
    // var operation = prismWebDB.getCollection('elasticubes')
    //     .deleteMany({ title: { $nin: Object.keys(datasourcesObj) } });
    // logger('deleted: ' + operation.acknowledged + ' | removed cubes: ' + operation.deletedCount);
}