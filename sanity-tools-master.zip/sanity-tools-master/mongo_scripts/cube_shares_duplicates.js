﻿/**
 * Created by yaroslav.korzh
 * Updated 02/05/2019
 */
// General Info
var version = '3.0.0';
var scriptName = 'Cube shares duplicates';

// Configuration
var showLogs = true;
var doCleanup = false;
if (typeof globalCleanup !== 'undefined') {
    // global cleanup
    // comment line below to use local cleanup flag
    doCleanup = globalCleanup;
}

var showShareDuplicates = false;

var config = {
    cleanup: {
        doCleanup: doCleanup
    },
    logging: {
        showLogs: showLogs,
        showShareDuplicates: showShareDuplicates
    }
};

// Common Functions
var checkForHexRegExp = new RegExp('^[0-9a-fA-F]{24}$');
var prismWebDB = db.getSiblingDB('prismWebDB');
var prismConfig = db.getSiblingDB('prismConfig');

function getStatus(flag) {
    return flag ? 'enabled' : 'disabled';
}

function logger(msg) {
    if (showLogs) {
        print(msg);
    }
}

function getIssuesStatus(flag) {
    return flag ? 'fixed' : 'found';
}

function collectStats(key, value) {
    if (typeof collectedStats !== 'undefined') {
        if (collectedStats[key]) {
            collectedStats[key] += value;
        } else {
            collectedStats[key] = value;
        }
    } else {
        collectedStats = {};
        collectedStats[key] = value;
    }
}

function printStats() {
    if (typeof globalRun == 'undefined') {
        logger(scriptName + ' statistics ' + ' © Sisense');
        logger('Total issues ' + getIssuesStatus(doCleanup) + ': ' + filterCount);
        print(JSON.stringify(collectedStats, undefined, 2));

        logger(
            '================================================================================================================');
    }
}

// *** Basic Functions ***
function isEmptyObject(obj) {
    for (var prop in obj) {
        if (obj.hasOwnProperty(prop)) {
            return false;
        }
    }
    return true;
}

function parseObjectIdToString(id) {
    if (typeof id === 'string') {
        return id;
    } else {
        return id.str;
    }
}

function parseStringToObjectId(id) {
    if (typeof id === 'string') {
        return ObjectId(id);
    } else {
        return id;
    }
}

function validateObjectId(id) {
    var stringId = parseObjectIdToString(id);
    return checkForHexRegExp.test(stringId);
}

var objectIdFromDate = function (date) {
    return Math.floor(date.getTime() / 1000).toString(16) + '0000000000000000';
};
var dateFromObjectId = function (objectId) {
    return new Date(parseInt(objectId.substring(0, 8), 16) * 1000);
};

// Base functions
function printHeader() {
    var logsStatus = getStatus(showLogs);
    var cleanupStatus = getStatus(doCleanup);
    print(
        '================================================================================================================');
    print(scriptName + ' ' + version + ' © Sisense | cleanup ' + cleanupStatus + ' | logs ' +
        logsStatus);
    print(new Date());
    print(
        '================================================================================================================');
}

function printConfig(config) {
    print('========== Configuration ==========');
    print(JSON.stringify(config, undefined, 2));
    print('====================================');
}

printHeader();
printConfig(config);

// Global variables
var maxDuplicates = 0;
var maxShares = 0;
var bulk = prismWebDB.getCollection('elasticubes').initializeUnorderedBulkOp();

// Functions
function checkCubesShares() {
    prismWebDB.getCollection('elasticubes').find({}).forEach(function (cube) {
        //logger('cube shares: ' + cube.shares.length);
        if (cube.shares.length > maxShares) {
            maxShares = cube.shares.length;
        }
        var sharesObj = {};
        var sharesToKeep = [];
        if (cube.shares) {
            cube.shares.forEach(function (share, index) {
                //logger('==================== Widget ========================');
                //logger(share.partyId + ' | ' + index + ' | ' + share.type + ' | ' + share.permission );
                if (sharesObj[share.partyId]) {
                    sharesObj[share.partyId].count += 1;
                    sharesObj[share.partyId].agg.push(share);
                } else {
                    sharesObj[share.partyId] = share;
                    sharesObj[share.partyId].count = 1;
                    sharesObj[share.partyId].agg = [];
                    sharesObj[share.partyId].agg.push(share);
                    sharesToKeep.push(
                        { partyId: share.partyId, type: share.type, permission: share.permission });
                }

                //logger('====================================================');
            });
            Object.keys(sharesObj).forEach(function (item) {

                var share = sharesObj[item];
                if (share.count > 1) {
                    if (share.count > maxDuplicates) {
                        maxDuplicates = share.count;
                    }
                    collectStats('cube_shares_duplicates', 1);
                    logger('You have duplicates in shares collection for cube');
                    logger('Duplicate: ' + item + ' | ' + share.type + ' | ' + share.permission +
                        ' - count: ' + share.count);
                    logger('--------------------------');
                    if (showShareDuplicates) {
                        share.agg.forEach(function (share, index) {
                            logger(share.partyId + ' | ' + index + ' | ' + share.type + ' | ' +
                                share.permission);
                        });
                    }
                    logger('====================================================');
                }

            });
            if (cube.shares.length === sharesToKeep.length) {
                //logger('Shares normalized ');
            } else if (doCleanup) {
                logger('Keep shares: ' + sharesToKeep.length);
                prismWebDB.getCollection('elasticubes').update(
                    { '_id': cube._id },
                    { $set: { 'shares': sharesToKeep } }
                );
            }
        } else {
            logger('Cube ' + cube.title + ' has no shares');
        }

    });

    if (maxDuplicates > 0) {
        logger('Max duplicates in shares ' + maxDuplicates + ' copies');
    } else {
        logger('No duplicates in collection');
    }

    logger('Max shares array ' + maxShares + ' items');
}

// Main script
checkCubesShares();