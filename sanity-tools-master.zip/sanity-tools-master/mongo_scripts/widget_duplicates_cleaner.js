﻿/**
 * Created by yaroslav.korzh
 * Updated 02/05/2019
 */
// General Info
var version = '3.0.0';
var scriptName = 'Widget duplicates cleaner';

// Configuration
var showLogs = true;
var doCleanup = false;
if (typeof globalCleanup !== 'undefined') {
    // global cleanup
    // comment line below to use local cleanup flag
    doCleanup = globalCleanup;
}

var deleteUserInstances = doCleanup;

var showExtendedInfo = false;
var useUserAndProxy = false;
var showParentInfo = false;
var waitTime = 10;
var limit = 10000;
var queryLimit = 0;
var widgetLimit = 0;
var skip = 0;
var useChunks = true;
var chunkSize = 2000;
var documentKeys = {
    title: '$title',
    oid: '$oid',
    userId: '$userId',
    instanceType: '$instanceType',
    lastUpdated: '$lastUpdated',
    _id: '$_id'
};
var dashAgg = {
    oid: '$oid',
    userId: '$userId',
    instanceType: '$instanceType'
};
var widgetAgg = {
    oid: '$oid',
    userId: '$userId',
    instanceType: '$instanceType',
    dashboardid: '$dashboardid'
};
var aggregationOptions = {
    allowDiskUse: true
};

var config = {
    cleanup: {
        doCleanup: doCleanup,
        deleteUserInstances: deleteUserInstances
    },
    logging: {
        showLogs: showLogs,
        showExtendedInfo: showExtendedInfo,
        useUserAndProxy: useUserAndProxy,
        showParentInfo: showParentInfo
    },
    limits: {
        useChunks: useChunks,
        chunkSize: chunkSize,
        limit: limit,
        queryLimit: queryLimit,
        widgetLimit: widgetLimit,
        skip: skip
    },
    aggregations: {
        dashAgg: dashAgg,
        widgetAgg: widgetAgg,
        documentKeys: documentKeys,
        aggregationOptions: aggregationOptions
    }
};

// Common Functions
var checkForHexRegExp = new RegExp('^[0-9a-fA-F]{24}$');
var prismWebDB = db.getSiblingDB('prismWebDB');
var prismConfig = db.getSiblingDB('prismConfig');

function getStatus(flag) {
    return flag ? 'enabled' : 'disabled';
}

function logger(msg) {
    if (showLogs) {
        print(msg);
    }
}

// *** Basic Functions ***
function isEmptyObject(obj) {
    for (var prop in obj) {
        if (obj.hasOwnProperty(prop)) {
            return false;
        }
    }
    return true;
}

function parseObjectIdToString(id) {
    if (typeof id === 'string') {
        return id;
    } else {
        return id.str;
    }
}

function parseStringToObjectId(id) {
    if (typeof id === 'string') {
        return ObjectId(id);
    } else {
        return id;
    }
}

function validateObjectId(id) {
    var stringId = parseObjectIdToString(id);
    return checkForHexRegExp.test(stringId);
}

var objectIdFromDate = function (date) {
    return Math.floor(date.getTime() / 1000).toString(16) + '0000000000000000';
};
var dateFromObjectId = function (objectId) {
    return new Date(parseInt(objectId.substring(0, 8), 16) * 1000);
};

// Base functions
function printHeader() {
    var logsStatus = getStatus(showLogs);
    var cleanupStatus = getStatus(doCleanup);
    print(
        '================================================================================================================');
    print(scriptName + ' ' + version + ' © Sisense | widget cleanup ' + cleanupStatus +
        ' | user instance widget cleanup ' + getStatus(deleteUserInstances) + ' | logs ' +
        logsStatus);
    print(new Date());
    print(
        '================================================================================================================');
}

function printConfig(config) {
    print('========== Configuration ==========');
    print(JSON.stringify(config, undefined, 2));
    print('====================================');
}

function getIssuesStatus(flag) {
    return flag ? 'fixed' : 'found';
}

function collectStats(key, value) {
    if (typeof collectedStats !== 'undefined') {
        if (collectedStats[key]) {
            collectedStats[key] += value;
        } else {
            collectedStats[key] = value;
        }
    } else {
        collectedStats = {};
        collectedStats[key] = value;
    }
}

function printStats() {
    if (typeof globalRun == 'undefined') {
        logger(scriptName + ' statistics ' + ' © Sisense');
        logger('Total issues ' + getIssuesStatus(doCleanup) + ': ' + filterCount);
        print(JSON.stringify(collectedStats, undefined, 2));

        logger(
            '================================================================================================================');
    }
}

printHeader();
printConfig(config);

// Global variables
var widgetsTotal = prismWebDB.getCollection('widgets').count();
var owners = {};
var topCopies = 0;
var topCopiedWidget = {};
var deleteIdsArr = [];
var dashboardsDuplicates;

// Main script
function printDashInfo(result) {
    logger('Dashboard info: ' + result.docs[0].title + ' | ' + result._id.oid + ' | ' +
        result._id.instanceType + ' | ' + result._id.userId + ' | ' + result.docs.length);
    if (showExtendedInfo) {
        result.docs.forEach(function (item) {
            var msg = '  Dashboard: ';
            Object.keys(item).forEach(function (key) {

                var value = item[key];

                msg += value + ' | ';
            });

            logger(msg);
        });

    }
}

function printWidgetInfo(result) {
    logger('Widget info: ' + result.docs[0].title + ' | ' + result._id.oid + ' | ' +
        result._id.instanceType + ' | ' + result._id.userId + ' | ' + result.docs.length);

    if (showExtendedInfo) {
        result.docs.forEach(function (item) {
            var msg = '  Widget: ';
            Object.keys(item).forEach(function (key) {

                var value = item[key];

                msg += value + ' | ';
            });

            logger(msg);
        });

    }
    if (result.docs.length > topCopies) {
        topCopies = result.docs.length;
        topCopiedWidget = result;
        logger(' new top copied widget: ' + result.docs.length);
    }
}

function printInfo(results) {
    var action = doCleanup ? 'start cleaning' : 'set "doCleanup = true;" to start cleaning';

    var duplicatesTotal = 0;
    var widgetsTotal = prismWebDB.getCollection('widgets').count();

    for (var k = 0, l = results.length; k < l; k++) {
        var result = results[k];
        duplicatesTotal += result.docs.length;
    }
    var value = (duplicatesTotal / widgetsTotal).toFixed(3);
    var duplicatesPercentage = value * 100;

    print('========== INFORMATION ==========');
    //print('Found ' + dashboardsDuplicates.length + ' duplicated dashboard instances');
    print('Found ' + results.length + ' duplication widget cases and ' + duplicatesTotal +
        ' duplicated widget instances');
    print('Total widgets ' + widgetsTotal + ' duplication: ' + duplicatesPercentage + ' %');
    collectStats('widget_duplicates_cases', results.length);
    collectStats('widget_duplicates_items', duplicatesTotal);
    if (duplicatesPercentage > 0 || dashboardsDuplicates.length > 0) {
        print(action);
    }

}

function printActions(owners) {
    print('========== ACTIONS ==========');
    logger(
        'to normalize these dashboards we remove all the junk widgets, most recently updated is kept, all others should be removed');
    logger('Top copied widget count: ' + topCopies);
    printWidgetInfo(topCopiedWidget);
    logger('to delete widgets set flag doCleanup = true');
    logger('After running this script for cleaning');
    logger('You may ask these users to republish their dashboards:');

    Object.keys(owners).forEach(function (item) {

        var userObj = owners[item];

        print(userObj.name + ' may republish dashboards:');
        if (userObj.dashboards) {
            Object.keys(userObj.dashboards).forEach(function (key, value) {
                item = userObj.dashboards[key];
                print(item.dashboardtitle + ' with oid ' + item.dashboardId);
            });
        }

        print('--------------------------');
    });
    print('=============================');
}

function getAggQuery(aggObject) {
    var query = [];
    if (queryLimit > 0) {
        query.push({ $limit: queryLimit });
    }
    if (skip > 0) {
        query.push({ $skip: skip });
    }
    query.push({
        $group: {
            _id: aggObject,
            count: { $sum: 1 },
            docs: { $push: documentKeys }
        }
    });
    query.push({
        $match: {
            count: { $gt: 1 }
        }
    });
    return query;
}

function getWidgetInfo(id, sourceSearch) {
    if (showParentInfo) {
        var searchId = parseStringToObjectId(id);
        var result = prismWebDB.getCollection('widgets').find({
            _id: searchId
        }).toArray();
        prismWebDB.getCollection('widgets').find({
            _id: searchId
        }).forEach(function (widget) {
            var text = 'widget info';
            if (sourceSearch) {
                text = 'Parent ' + text;
            }
            logger('********************* ' + text + ' ********************************');
            logger(widget.title + ' | ' + widget.oid + ' | ' + widget._id + ' | ' + widget.source +
                ' | ' + widget.created + ' | ' + widget.dashboardid + ' | ' + widget.owner + ' | ' +
                widget.instanceType + ' | ' + widget.userId + ' | ' + widget.lastUpdated + ' | ' +
                widget.lastUsed);
            //getDashboardInfo(widget.dashboardid)
            if (widget.source) {
                getWidgetInfo(widget.source, true);
            }
            logger('******************************************************************');
        });

        if (result.length === 0) {
            var text = 'widget not found';
            if (sourceSearch) {
                text = 'Parent ' + text;
            }
            logger('************************* ' + text + ' *******************************');
        }
    }
}

function getDashboardInfo(id, sourceSearch) {
    if (showParentInfo) {
        logger('Sourced from:');
        var searchId = parseStringToObjectId(id);
        var searchObj = {
            instanceType: 'owner'
        };
        if (sourceSearch) {
            searchObj['_id'] = searchId;
        } else {
            searchObj['oid'] = searchId;
        }
        var result = prismWebDB.getCollection('dashboards').find(searchObj).toArray();

        prismWebDB.getCollection('dashboards').find(searchObj).forEach(function (dash) {
            var text = 'Dashboard info';
            if (sourceSearch) {
                text = 'Parent ' + text;
            }
            logger('********************* ' + text + ' ********************************');
            logger('Dashboard: ' + dash._id + ' | ' + dash.title + ' | ' + dash.oid + ' | ' +
                dash.instanceType + ' | ' + dash.owner + ' | ' + dash.source + ' | ' +
                dash.lastUpdated);
            if (dash.source) {
                getDashboardInfo(dash.source, true);
            }
            logger('*********************************************************************');
        });

        if (result.length === 0) {
            var text = 'dashboard not found';
            if (sourceSearch) {
                text = 'Parent ' + text;
            }
            logger('************************* ' + text + '*******************************');
        }
    }
}

function fixInstance(result, bulk) {
    var data = {};
    var isOwner = result._id.instanceType === 'owner';

    if (result._id.instanceType === 'owner') {
        var owner = {};
        printWidgetInfo(result);
        prismWebDB.getCollection('users').find({ _id: result._id.userId }).forEach(function (user) {
            logger('User: ' + user.userName + ' | ' + user._id);
            Object.keys(owners).forEach(function (item) {
                var userObj = owners[item];
                if (user.userName) {
                    if (userObj.name === user.userName) {
                        owner = owners[user.userName];
                    }
                }
            });

            data.user = user.userName;
            owner.name = user.userName;
            prismWebDB.getCollection('dashboards').find({
                oid: result._id.dashboardid,
                instanceType: result._id.instanceType
            }).forEach(function (dash) {
                var dashboard = {};
                logger('Dashboard: ' + dash.title + ' | ' + dash.oid + ' | ' + dash.instanceType +
                    ' | ' + dash.owner + ' | ' + dash.created + ' | ' + dash.lastUpdated + ' | ' +
                    dash.source);
                data.dashoid = dash.oid;
                data.dashboardtitle = dash.title;
                dashboard.dashboardId = dash.oid;
                dashboard.dashboardtitle = dash.title;

                if (!owner.dashboards) {
                    owner.dashboards = {};
                }
                if (!owner.dashboards[dashboard.dashboardId.valueOf()]) {
                    owner.dashboards[dashboard.dashboardId.valueOf()] = dashboard;
                }

                if (dash.source !== 'undefined') {
                    getDashboardInfo(dash.source, true);
                }

            });

            owners[owner.name] = owner;
        });
        var dashboardCount = prismWebDB.getCollection('dashboards').count({
            oid: result._id.dashboardid,
            instanceType: result._id.instanceType
        });
    } else if (result._id.instanceType === 'proxy') {

        if (useUserAndProxy) {
            logger('Result is ' + result._id.instanceType +
                ' instance. Fixing owner instances solves it.');
        }
        //sleep(waitTime);
        var widgetCollection = prismWebDB.getCollection('widgets').find({
            oid: result._id.oid,
            userId: result._id.userId,
            instanceType: result._id.instanceType
        }).limit(widgetLimit).sort({ lastUpdated: -1 }).toArray();
        printWidgetInfo(result);
        widgetCollection.forEach(function (widget, index) {
            if (useUserAndProxy) {
                logger(
                    widget.title + ' | ' + index + ' | ' + widget.oid + ' | ' + widget._id + ' | ' +
                    widget.source + ' | ' + widget.instanceType + ' | ' + widget.owner + ' | ' +
                    widget.userId + ' | ' + widget.dashboardid + ' | ' + widget.lastUpdated +
                    ' | ' + widget.created + ' | ' + widget.lastUsed);
            }
            getWidgetInfo(widget.source, true);
            if (deleteUserInstances && index > 0) {
                //var res = prismWebDB.widgets.deleteOne({"_id": widget._id});
                //logger(widget.title + ' added to bulk delete ');
                bulk.find({ '_id': widget._id }).remove();
                //logger(widget.title + ' deleted: ' );//+ res.deletedCount
            }
        });
        //logger(widgetCollection.length + ' widgets processed ' );
        //logger('******************************************************************');
    } else if (result._id.instanceType === 'user') {

        if (useUserAndProxy) {
            logger('Result is ' + result._id.instanceType +
                ' instance. Fixing owner instances solves it.');
        }
        //sleep(waitTime);
        var widgetCollection = prismWebDB.getCollection('widgets').find({
            oid: result._id.oid,
            userId: result._id.userId,
            instanceType: result._id.instanceType
        }).limit(widgetLimit).toArray();
        printWidgetInfo(result);
        widgetCollection.forEach(function (widget, index) {
            if (useUserAndProxy) {
                logger(
                    widget.title + ' | ' + index + ' | ' + widget.oid + ' | ' + widget._id + ' | ' +
                    widget.source + ' | ' + widget.instanceType + ' | ' + widget.owner + ' | ' +
                    widget.userId + ' | ' + widget.dashboardid + ' | ' + widget.lastUpdated +
                    ' | ' + widget.created + ' | ' + widget.lastUsed);
            }
            getWidgetInfo(widget.source, true);
            if (deleteUserInstances && index > 0) {
                //var res = prismWebDB.widgets.deleteOne({"_id": widget._id});
                //logger(widget.title + ' added to bulk delete ');
                bulk.find({ '_id': widget._id }).remove();
                //logger(widget.title + ' deleted: ' );//+ res.deletedCount
            }
        });
        //logger(widgetCollection.length + ' widgets processed ' );
        //logger('******************************************************************');

    }

    if (dashboardCount > 0 && isOwner) {
        var resObj = {};
        logger('You have multiple owner widgets with the same oid:');
        logger(
            ' title |  oid  |  _id  | source  | instanceType | owner | user | dashboardid |  lastUpdated  | created  | lastUsed ');
        var widgetsArr = prismWebDB.getCollection('widgets').find({
            oid: result._id.oid,
            userId: result._id.userId,
            instanceType: result._id.instanceType
        }).limit(widgetLimit).sort({ lastUpdated: -1 }).toArray();
        var widgetCollection = prismWebDB.getCollection('widgets').find({
            oid: result._id.oid,
            userId: result._id.userId,
            instanceType: result._id.instanceType
        }).limit(widgetLimit).sort({ lastUpdated: -1 }).toArray();
        printWidgetInfo(result);
        widgetCollection.forEach(function (widget, index) {
            logger('==================== Widget ========================');
            logger(widget.title + ' | ' + index + ' | ' + widget.oid + ' | ' + widget._id + ' | ' +
                widget.source + ' | ' + widget.created + ' | ' + widget.dashboardid + ' | ' +
                widget.owner + ' | ' + widget.instanceType + ' | ' + widget.userId + ' | ' +
                widget.lastUpdated + ' | ' + widget.lastUsed);
            if (widget.source) {
                getWidgetInfo(widget.source, true);
            }
            logger('====================================================');
        });

        if (doCleanup) {
            for (var ii = 1; ii < widgetsArr.length; ii++) {
                var widget = widgetsArr[ii];

                //var res = prismWebDB.widgets.deleteOne({"_id": widget._id});
                bulk.find({ '_id': widget._id }).removeOne();
                //logger(widget.title + ' deleted: ' + res.deletedCount);
                deleteIdsArr.push(widget._id);
            }
            //logger('----------------------------------------------------');
            logger(
                'Now dashboard owner ' + data.user + ' needs to republish ' + data.dashboardtitle +
                ' with id ' + data.dashoid);
        } else {

        }

        logger('    ');
    } else if (dashboardCount === 0) {
        logger('no related dashboard found, you need to delete ' + result.docs.length +
            ' redundant widgets');
        for (var k = 0, l = result.docs.length; k < l; k++) {
            var res = result.docs[k];
            print(JSON.stringify(res));
            prismWebDB.getCollection('widgets')
                .find({ _id: res })
                .limit(widgetLimit)
                .sort({ lastUpdated: -1 })
                .toArray()
                .forEach(function (widget) {
                    logger(widget.title + ' | ' + widget.oid + //' | ' + widget._id.getTimestamp().getTime() +
                        ' | ' + widget._id + ' | ' + widget.instanceType + ' | ' +
                        widget.lastUpdated + ' | ' + widget.created + ' | ' + widget.lastUsed);
                    var res = prismWebDB.widgets.deleteOne({ '_id': widget._id });
                    logger(widget.title + ' deleted: ' + res.deletedCount);
                });

        }
        logger(
            '==================================================================================================================================================================================================================');
    }
}

function fixDashboardInstance(result, bulk) {
    //print('--------------------------');
    printDashInfo(result);
    var dashboardCollection = prismWebDB.getCollection('dashboards').find({
        oid: result._id.oid,
        userId: result._id.userId,
        instanceType: result._id.instanceType
    }).limit(limit).sort({ lastUpdated: -1 }).toArray();

    dashboardCollection.forEach(function (dash, index) {
        var msg = 'Dashboard info: ' +
            dash.title + ' | '
            //+ index + ' | '
            + dash.oid + ' | '
            + dash.userId + ' | '
            + dash.owner + ' | '
            + dash.source + ' | '
            + dash.instanceType + ' | '
            + dash._id + ' | '
            + dash.lastUpdated + ' | '
            + dash.created + ' | '
            + dash.lastUsed;
        //logger(msg);

        if (doCleanup && index > 0) {
            //var res = prismWebDB.widgets.deleteOne({"_id": dash._id});
            //logger(dash.title + ' added to bulk delete ');
            bulk.find({ '_id': dash._id }).remove();
            //logger(dash.title + ' deleted: ' );//+ res.deletedCount
        }
    });
}

var dashAggQuery = getAggQuery(dashAgg);
var widgetAggQuery = getAggQuery(widgetAgg);
dashboardsDuplicates = prismWebDB.getCollection('dashboards')
    .aggregate(dashAggQuery, aggregationOptions)
    .toArray();

logger('Aggregated dashboards ' + dashboardsDuplicates.length);
logger('Limit widget agg ' + queryLimit);
logger('Total widgets ' + widgetsTotal);

var resultsGlobal = prismWebDB.getCollection('widgets')
    .aggregate(widgetAggQuery, aggregationOptions)
    .toArray();
logger('Aggregated widgets ' + resultsGlobal.length);

function cleanDashboards(dashboards) {
    var action = doCleanup ? 'start cleaning' : 'set "doCleanup = true;" to start cleaning';
    var bulk = prismWebDB.getCollection('dashboards').initializeUnorderedBulkOp();
    var duplicatesTotal = 0;
    var dashboardsTotal = prismWebDB.getCollection('dashboards').count();

    for (var k = 0, l = dashboards.length; k < l; k++) {
        var dash = dashboards[k];
        duplicatesTotal += dash.docs.length;
    }
    var value = (duplicatesTotal / dashboardsTotal).toFixed(3);
    var duplicatesPercentage = value * 100;
    print('   ');
    print('========== Duplicated dashboards ==========');
    print('Found ' + dashboards.length + ' duplication dashboard cases and ' + duplicatesTotal +
        ' duplicated dashboard instances');
    collectStats('dashboard_duplicates_cases', dashboards.length);
    collectStats('dashboard_duplicates_items', duplicatesTotal);
    print('Total dashboards ' + dashboardsTotal + ' duplication: ' + duplicatesPercentage + ' %');
    if (duplicatesPercentage > 0 || dashboards.length > 0) {
        print(action);
    }
    print('---------- RESULTS ----------');
    for (var i = 0, l = dashboards.length; i < l; i++) {
        var result = dashboards[i];

        if (result) {
            sleep(waitTime);
            fixDashboardInstance(result, bulk);
        }
    }
    if (doCleanup) {
        logger('Bulk dashboards delete execute');
        var bulkResult = bulk.execute();
        logger(bulkResult);
    }
    print('========== Finished dashboards processing ==========');
    print('   ');
}

function cleanDB(results) {
    var bulk = prismWebDB.getCollection('widgets').initializeUnorderedBulkOp();

    var reRun = false;
    if (!results) {
        logger('Updating results');
        results = prismWebDB.getCollection('widgets')
            .aggregate(widgetAggQuery, aggregationOptions)
            .toArray();
    }
    printInfo(results);
    if (results.length > 0) {
        logger('Results total: ' + results.length + ' chunk size: ' + chunkSize);
        if (useChunks && results.length > chunkSize) {
            logger('Results is more than chunk size, splitting operations');
            results = results.slice(0, chunkSize);
            reRun = true;
        }
        print('---------- RESULTS ----------');
        for (var i = 0, l = results.length; i < l; i++) {
            var result = results[i];

            if (result) {
                sleep(waitTime);
                fixInstance(result, bulk);
            }
        }

        if (doCleanup || deleteUserInstances) {
            logger('Bulk delete execute');
            var result = bulk.execute();
            logger(result);
            if (reRun) {
                logger('Starting new iteration');
                sleep(waitTime);
                cleanDB();
            } else {
                printActions(owners);
            }
        }
    } else {
        print('Your mongo is free from widget duplicates');
        logger(
            '======================================================================================================================================================');

    }

}

var index = 0;
if (doCleanup) {

}

cleanDashboards(dashboardsDuplicates);
cleanDB(resultsGlobal);

printStats();