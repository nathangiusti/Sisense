/**
 * Created by yaroslav.korzh
 * Updated 02/05/2019
 */
// General Info
var version = '3.0.0';
var scriptName = 'Jobs validate';

// Configuration
var showLogs = true;
var doCleanup = false;
if (typeof globalCleanup !== 'undefined') {
    // global cleanup
    // comment line below to use local cleanup flag
    doCleanup = globalCleanup;
}

var config = {
    cleanup: {
        doCleanup: doCleanup
    },
    logging: {
        showLogs: showLogs
    }
};

// Common Functions
var checkForHexRegExp = new RegExp('^[0-9a-fA-F]{24}$');
var prismWebDB = db.getSiblingDB('prismWebDB');
var prismConfig = db.getSiblingDB('prismConfig');

function getStatus(flag) {
    return flag ? 'enabled' : 'disabled';
}

function logger(msg) {
    if (showLogs) {
        print(msg);
    }
}

function getIssuesStatus(flag) {
    return flag ? 'fixed' : 'found';
}

function collectStats(key, value) {
    if (typeof collectedStats !== 'undefined') {
        if (collectedStats[key]) {
            collectedStats[key] += value;
        } else {
            collectedStats[key] = value;
        }
    } else {
        collectedStats = {};
        collectedStats[key] = value;
    }
}

function printStats() {
    if (typeof globalRun == 'undefined') {
        logger(scriptName + ' statistics ' + ' © Sisense');
        logger('Total issues ' + getIssuesStatus(doCleanup) + ': ' + filterCount);
        print(JSON.stringify(collectedStats, undefined, 2));

        logger(
            '================================================================================================================');
    }
}

// *** Basic Functions ***
function isEmptyObject(obj) {
    for (var prop in obj) {
        if (obj.hasOwnProperty(prop)) {
            return false;
        }
    }
    return true;
}

function parseObjectIdToString(id) {
    if (typeof id === 'string') {
        return id;
    } else {
        return id.str;
    }
}

function parseStringToObjectId(id) {
    if (typeof id === 'string') {
        return ObjectId(id);
    } else {
        return id;
    }
}

function validateObjectId(id) {
    var stringId = parseObjectIdToString(id);
    return checkForHexRegExp.test(stringId);
}

var objectIdFromDate = function (date) {
    return Math.floor(date.getTime() / 1000).toString(16) + '0000000000000000';
};
var dateFromObjectId = function (objectId) {
    return new Date(parseInt(objectId.substring(0, 8), 16) * 1000);
};

// Base functions
function printHeader() {
    var logsStatus = getStatus(showLogs);
    var cleanupStatus = getStatus(doCleanup);
    print(
        '================================================================================================================');
    print(scriptName + ' ' + version + ' © Sisense | cleanup ' + cleanupStatus + ' | logs ' +
        logsStatus);
    print(new Date());
    print(
        '================================================================================================================');
}

function printConfig(config) {
    print('========== Configuration ==========');
    print(JSON.stringify(config, undefined, 2));
    print('====================================');
}

printHeader();
printConfig(config);

// Global variables
var brokenJobs = 0;
var jobDashboards = [];
// Functions
// *** Jobs Validation Functions ***
function validateSubscriptionJob(job) {
    var dashboardId = parseStringToObjectId(job.dashboardId);
    var dashCount = prismWebDB.dashboards.count({ oid: dashboardId });
    var widgetCount = prismWebDB.widgets.count({ dashboardid: dashboardId });
    // If there are no dashboards and no widgets (meaning that the dashboard was deleted)
    return !(dashCount === 0 && widgetCount === 0);
}

function validateJob(job) {
    var isValid = true,
        isJobToDelete = false;

    if (!validateObjectId(job._id)) {
        isValid = false;
        collectStats('job_invalid_id', 1);
        print('Job (_id): ' + job._id + ' has invalid job id');
    }

    if (job.jobType === 'dashboardSubscription' && !validateSubscriptionJob(job)) {
        isJobToDelete = true;
        collectStats('job_on_nonexistent_dashboard', 1);
        print('Job (_id): ' + job._id + ' is related to a dashboard which does not exist (oid): ' +
            job.dashboardId);
        //print("db.getSiblingDB('prismWebDB').jobs.remove({_id: ObjectId('" + job._id + "')});");

        brokenJobs += 1;
        if (doCleanup) {
            prismWebDB.jobs.remove({ _id: job._id });
        }
        //print("db.dashboards.find({oid: ObjectId('" + job.dashboardId + "')})");
    }

    if (!isValid && !isJobToDelete) {
        print('db.getSiblingDB(\'prismWebDB\').jobs.find({_id: ObjectId(\'' + job._id + '\')});');
    }
}

function validateAllJobs() {

    var bulkSize = 10;
    var jobCount = prismWebDB.jobs.count();
    print('Validating all ' + jobCount + ' jobs ');
    for (var i = 0; i < jobCount; i = i + bulkSize) {
        var bulkJobs = prismWebDB.jobs
            .find({}, { _id: 1, jobType: 1, dashboardId: 1 })
            .skip(i).limit(bulkSize).toArray();
        print('Validating job chunk ' + bulkJobs.length + ' jobs, step ' + i + ' size ' +
            bulkSize);
        bulkJobs.forEach(function (job) {
            validateJob(job);
        });
    }

    //prismWebDB.jobs.find({}, {_id: 1, jobType: 1, dashboardId: 1}).forEach(function(job){

    //});
    logger('Broken jobs ' + brokenJobs + ' copies');
    print('Validating all jobs has ended.');
}

// Main script

prismWebDB.getCollection('jobs')
    .find({ active: false, jobType: 'dashboardSubscription' })
    .forEach(function (job) {
        jobDashboards.push(job.dashboardId);
    });

jobDashboards.forEach(function (dashboard) {
    //print(dashboard)
    prismWebDB.getCollection('dashboards')
        .find({ oid: ObjectId(dashboard), instanceType: 'owner' })
        .forEach(function (dash) {
            //print(dash.title);
        });
});

validateAllJobs();

