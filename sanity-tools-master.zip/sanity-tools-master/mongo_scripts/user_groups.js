/**
 * Created by yaroslav.korzh
 * Updated 02/05/2019
 */
var version = '3.0.0';
var scriptName = 'Users group duplicates';

// Configuration
var showLogs = true;
var doCleanup = false;
if (typeof globalCleanup !== 'undefined') {
    // global cleanup
    // comment line below to use local cleanup flag
    doCleanup = globalCleanup;
}

var cleanGroups = doCleanup;
var config = {
    cleanup: {
        doCleanup: doCleanup,
        cleanGroups: cleanGroups
    },
    logging: {
        showLogs: showLogs
    }
};

var cleanupStatus = doCleanup ? 'enabled' : 'disabled';
var logsStatus = showLogs ? 'enabled' : 'disabled';

var prismWebDB = db.getSiblingDB('prismWebDB');
var prismConfig = db.getSiblingDB('prismConfig');

function logger(msg) {
    if (showLogs) {
        print(msg);
    }
}

function getStatus(flag) {
    return flag ? 'enabled' : 'disabled';
}

function collectStats(key, value) {
    if (typeof collectedStats !== 'undefined') {
        if (collectedStats[key]) {
            collectedStats[key] += value;
        } else {
            collectedStats[key] = value;
        }
    } else {
        collectedStats = {};
        collectedStats[key] = value;
    }
}

function printStats() {
    if (typeof globalRun == 'undefined') {
        logger(scriptName + ' statistics ' + ' © Sisense');
        logger('Total issues ' + getIssuesStatus(doCleanup) + ': ' + filterCount);
        print(JSON.stringify(collectedStats, undefined, 2));

        logger(
            '================================================================================================================');
    }
}

function printConfig(config) {
    print('========== Configuration ==========');
    print(JSON.stringify(config, undefined, 2));
    print('====================================');
}

// Base functions
function printHeader() {
    var logsStatus = getStatus(showLogs);
    var cleanupStatus = getStatus(doCleanup);
    print(
        '================================================================================================================');
    print(scriptName + ' ' + version + ' © Sisense | cleanup ' + cleanupStatus + ' | logs ' +
        logsStatus);
    print(new Date());
    print(
        '================================================================================================================');
}

function onlyUnique(value, index, self) {
    return self.indexOf(value) === index;
}

printHeader();
printConfig(config);

function getIssuesStatus(flag) {
    return flag ? 'fixed' : 'found';
}

prismWebDB.getCollection('users').find({}).forEach(function (user) {

    var results = prismWebDB.getCollection('users').aggregate([
        { '$match': { '_id': user._id } },
        { '$project': { 'groups': 1, '_id': 0 } },
        { '$unwind': '$groups' },
        { '$group': { '_id': '$groups', 'count': { '$sum': 1 } } },
        { '$match': { 'count': { '$gt': 1 } } }
    ]).toArray();
    if (results.length > 0) {
        logger('User: ' + user.userName + ' | ' + user._id + ' | ' + user.roleId);
        prismConfig.getCollection('roles').find({ _id: user.roleId }).forEach(function (role) {
            logger('role id: ' + role._id + ' role name: ' + role.displayName);
        });

        results.forEach(function (result) {
            collectStats('duplicated_user_group_items', 1);
            prismWebDB.getCollection('groups')
                .find({ '_id': ObjectId(result._id) })
                .forEach(function (group) {
                    logger('group name: ' + group.name);
                });
            logger('group id: ' + result._id + ' count: ' + result.count);
            if (doCleanup) {
                var groups = user.groups.filter(onlyUnique);
                logger(' keep groups: ' + groups.length);
                prismWebDB.getCollection('users').update(
                    { _id: user._id },
                    { $set: { groups: groups } }
                );
            }

        });
        print(
            '================================================================================================================');
    }

});