/**
 * Created by yaroslav.korzh
 * Updated 02/05/2019
 */
// General Info
var version = '3.0.0';
var scriptName = 'Users validate';

// Configuration
var showLogs = true;
var doCleanup = false;
if (typeof globalCleanup !== 'undefined') {
    // global cleanup
    // comment line below to use local cleanup flag
    doCleanup = globalCleanup;
}

var cleanGroups = doCleanup;
var config = {
    cleanup: {
        doCleanup: doCleanup,
        cleanGroups: cleanGroups
    },
    logging: {
        showLogs: showLogs
    }
};

// Common Functions
var checkForHexRegExp = new RegExp('^[0-9a-fA-F]{24}$');
var prismWebDB = db.getSiblingDB('prismWebDB');
var prismConfig = db.getSiblingDB('prismConfig');

function getStatus(flag) {
    return flag ? 'enabled' : 'disabled';
}

function logger(msg) {
    if (showLogs) {
        print(msg);
    }
}

function getIssuesStatus(flag) {
    return flag ? 'fixed' : 'found';
}

function collectStats(key, value) {
    if (typeof collectedStats !== 'undefined') {
        if (collectedStats[key]) {
            collectedStats[key] += value;
        } else {
            collectedStats[key] = value;
        }
    } else {
        collectedStats = {};
        collectedStats[key] = value;
    }
}

function printStats() {
    if (typeof globalRun == 'undefined') {
        logger(scriptName + ' statistics ' + ' © Sisense');
        logger('Total issues ' + getIssuesStatus(doCleanup) + ': ' + filterCount);
        print(JSON.stringify(collectedStats, undefined, 2));

        logger(
            '================================================================================================================');
    }
}

// *** Basic Functions ***
function isEmptyObject(obj) {
    for (var prop in obj) {
        if (obj.hasOwnProperty(prop)) {
            return false;
        }
    }
    return true;
}

function parseObjectIdToString(id) {
    if (typeof id === 'string') {
        return id;
    } else {
        return id.str;
    }
}

function parseStringToObjectId(id) {
    if (typeof id === 'string') {
        return ObjectId(id);
    } else {
        return id;
    }
}

function validateObjectId(id) {
    var stringId = parseObjectIdToString(id);
    return checkForHexRegExp.test(stringId);
}

var objectIdFromDate = function (date) {
    return Math.floor(date.getTime() / 1000).toString(16) + '0000000000000000';
};
var dateFromObjectId = function (objectId) {
    return new Date(parseInt(objectId.substring(0, 8), 16) * 1000);
};

// Base functions
function printHeader() {
    var logsStatus = getStatus(showLogs);
    var cleanupStatus = getStatus(doCleanup);
    print(
        '================================================================================================================');
    print(scriptName + ' ' + version + ' © Sisense | cleanup ' + cleanupStatus + ' | logs ' +
        logsStatus);
    print(new Date());
    print(
        '================================================================================================================');
}

function printConfig(config) {
    print('========== Configuration ==========');
    print(JSON.stringify(config, undefined, 2));
    print('====================================');
}

printHeader();
printConfig(config);

// Global variables
var allRoles = {}; // Hashmap of all roles

// Functions

// *** Group Validation Functions ***
function isGroupIdExists(id) {
    var groupId = parseStringToObjectId(id);
    // If we found a group with the given id
    var groupExists = prismWebDB.groups.find({ _id: groupId }).limit(1).hasNext();
    return groupExists;
}

function validateGroupId(id) {
    return (validateObjectId(id) && isGroupIdExists(id));
}

// *** Main Functions ***
function validateAllUsers() {
    var userCount = prismWebDB.users.count({});
    print('Validating ' + userCount + ' users');
    prismWebDB.users.find({}, { roleId: 1, _id: 1, groups: 1 }).forEach(function (user) {
        var isValid = true;
        var hasChanges = false;

        if (!validateObjectId(user._id)) {
            isValid = false;
            print('User (_id): ' + user._id + ' has invalid user id');
            collectStats('user_invalid_id', 1);
        }

        if (user.groups) {
            user.groups.forEach(function (groupIdString, index, groups) {
                if (!validateGroupId(groupIdString)) {
                    isValid = false;
                    collectStats('user_invalid_group_id', 1);
                    print('User (_id): ' + user._id + ' has invalid group id: ' + groupIdString);
                    if (doCleanup && cleanGroups) {
                        print('Removing group from user');
                        hasChanges = true;
                        user.groups.splice(index, 1);
                    }
                }
            });

        }

        if (!validateRoleId(user.roleId)) {
            isValid = false;
            collectStats('user_invalid_role_id', 1);
            print('User (_id): ' + user._id + ' has invalid role id: ' + user.roleId);
        }

        if (doCleanup && cleanGroups && hasChanges) {
            print('Update user groups');
            prismWebDB.getCollection('users').update(
                { _id: user._id },
                { $set: { 'groups': user.groups } },
                { multi: false }
            );
        }

        if (!isValid) {
            print('db.getSiblingDB(\'prismWebDB\').users.find({_id: ObjectId(\'' + user._id +
                '\')});');
        }
    });
    print('Validating all users has ended.');
}

// *** Roles Validation Functions ***
function initAllRoles() {
    prismConfig.roles.find({}, { _id: 1 }).forEach(function (role) {
        var roleIdString = parseObjectIdToString(role._id);
        allRoles[roleIdString] = roleIdString;
    });
}

function isRoleIdExists(id) {

    var roleIdString = parseObjectIdToString(id);
    // Initializing the roles hashmap
    if (isEmptyObject(allRoles)) {
        initAllRoles();
    }

    return allRoles.hasOwnProperty(roleIdString);
}

function validateRoleId(userRole) {
    if (!userRole) {
        collectStats('user_has_no_role', 1);
        print('User has no role');
        return;
    }
    return isRoleIdExists(userRole);
}

// Main script

validateAllUsers();
