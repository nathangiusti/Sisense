prism.run([
    "plugin-SwitchDimension.services.bindOnce",
    function ($bindOnce) {
        var maxItemsBeforeSubMenuIsCreatedDefault = 5;		
        // mapping of widgetId to dimensionSettings that comes from the widget script
        var dimSettings = {};


        function onBeforeMenu(e, args) {
            if (args.settings.name !== "datapoint")
                return;

            var widget = $$get(args, "settings.widget");
            var pluginConfig = dimSettings[widget.oid];

            if (!pluginConfig) {
                return;
            }

            var dimensionSettings = pluginConfig.dimensions;
			
			dimensionSettings.forEach(function(config) {
				var items = widget.metadata.panel(config.panel).items;
				config.dims.forEach(function(item) {
					if (items[item.index].jaql.dim === item.dim && items[item.index].hierarchies !== item.hierarchies) {
						items[item.index].hierarchies = item.hierarchies;
                        widget.changesMade();						
					}
				})
			})

            //converting old config to new
            if (isOldConfig(dimensionSettings)) {
                dimensionSettings = convertOldConfig(dimensionSettings);
            }

            var shouldCreateSubMenu = isNeededToCreateSubMenu(dimensionSettings, dimSettings[widget.oid].maxItemsBeforeSubMenuIsCreated);

            var menuItems = [];
						
            dimensionSettings.forEach(function (item) {

                var panel = item.panel.toLowerCase();
                var affectToAll = item.affectAllWidgets;
                var menuItemsPerPanel = [];
                item.dims.forEach(function (settings) {

                    if (!settings.dim || !panel || !defined(settings.index)) {
                        console.log('Invalid parameters');
                        return;
                    }

                    var dimensionIndex = settings.index;

                    if (!defined(widget.metadata.panel(panel).items[dimensionIndex])) {
                        return;
                    }

                    var panelItem = widget.metadata.panel(panel).items[dimensionIndex];
                    var isCurrentDimension = panelItem.jaql.dim.toLowerCase() === settings.dim.toLowerCase();

                    if (isCurrentDimension) {
						if (settings.hierarchies) {
							console.log(settings.hierarchies)
							widget.metadata.panel(panel).items[dimensionIndex].hierarchies = settings.hierarchies;
						}
						return;
					}

                    var dimFormatted = settings.dim.replace(/[\[\]']+/g, '');
                    var jaql = {
                        dim: settings.dim,
                        title: settings.title,
                        datatype: settings.datatype,
                        agg: settings.agg || undefined,
                        level: settings.level || undefined,
                        column: dimFormatted.substr(settings.dim.indexOf('.'), settings.dim.length),
                        table: dimFormatted.substr(0, settings.dim.indexOf('.') - 1)
                    };

                    var widgetTitle = getWidgetTitle(settings, jaql);

                    var executeFunction = function () {
                        if (affectToAll === true) {
                            var widgets = prism.activeDashboard.widgets.$$widgets;

                            widgets.forEach(function (dashboardWidget) {
                                var panelDims = dashboardWidget.metadata.panel(panel);

                                if (!panelDims || dashboardWidget.oid === widget.oid)
                                    return;

                                if (!panelDims.items[dimensionIndex]) {
                                    return;
                                }

                                switchDimensions(panelDims.items[dimensionIndex], jaql);

                                dashboardWidget.changesMade();
                                dashboardWidget.refresh();
                            });
                        }

                        switchDimensions(panelItem, jaql);

                        if (widgetTitle) {
                            widget.title = widgetTitle;
                        }

						widget.metadata.panel(this.currentSettings.panel).items[this.currentSettings.dimensionIndex].hierarchies = this.currentSettings.hierarchies;
                        widget.changesMade();
                        widget.refresh();
                    };
					
					
                    menuItemsPerPanel.push({type: 'separator'});
                    menuItemsPerPanel.push({
                        caption: jaql.title || jaql.dim,
                        closing: true,
                        execute: executeFunction,
						currentSettings: {
							hierarchies: settings.hierarchies,
							panel: panel,
							dimensionIndex: dimensionIndex
						}
                    })
                });

                if (menuItemsPerPanel.length) {
                    menuItems.push({type: 'separator'});
                    menuItems.push({
                        type: 'header',
                        caption: panel,
                    });

                    menuItems = menuItems.concat(menuItemsPerPanel);
                }
            });

            if (shouldCreateSubMenu) {
                args.settings.items.push({
                    caption: 'Switch Dimensions',
                    items: menuItems
                })
            } else {
                menuItems.forEach(function (item) {
                    args.settings.items.push(item);
                })
            }
        }

        function switchDimensions(panelItem, newJaql) {
            _.extend(panelItem.jaql, newJaql);

        }

        function interpolateTemplate(templateString, dimTitle) {
            _.templateSettings = {
                interpolate: /\{\{(.+?)\}\}/g
            };
            var template = _.template(templateString);

            return template({dim: dimTitle});
        }

        function findDimensions(panel, dimensionsArray) {

            return dimensionsArray.filter(function (item) {

                return item.panel.toLowerCase() === panel.toLowerCase();
            });
        }

        //helps us to  prevent pushing already pushed panels
        function isPanelAlreadyPushed(newDimensionsSettings, panel) {
            var isPushed = _.findIndex(newDimensionsSettings, function (item) { //Need to use findIndex of underscore
                return item.panel === panel;                                    //for IE
            });

            return ~isPushed;
        }

        //checks if needed to create sub menu
        function isNeededToCreateSubMenu(dimensionsSettings, allowedLength) {
            var dimCount = 0;
            for (var key in dimensionsSettings) {
                dimCount += dimensionsSettings[key].dims.length;
            }

            return dimCount >= allowedLength;
        }

        //checking if there is old config
        function isOldConfig(dimensions) {
            return !dimensions[0].hasOwnProperty('dims')
        }

        //converting old config to a new config
        function convertOldConfig(oldDimensions) {
            return oldDimensions.reduce(function (dims, item, index, arr) {
                var panel = item.panel;
                var dimSetting = {};


                if (!isPanelAlreadyPushed(dims, panel) && defined(panel)) {
                    var dimsOfPanel = findDimensions(panel, arr);
                    dimSetting.panel = panel;
                    dimSetting.dims = [];

                    dimsOfPanel.map(function (item) {
                        var dimObj = {};

                        for (key in item) {
                            if (key !== 'panel') {
                                dimObj[key] = item[key];
                            }
                        }

                        dimSetting.dims.push(dimObj);
                    });

                    dimSetting.dims = dimsOfPanel;
                    dims.push(dimSetting);
                }

                return dims;
            }, []);
        }

        function getWidgetTitle(settings, jaql) {
            var widgetTitle = '';
            if (settings.widgetTitleTemplate) {
                widgetTitle = interpolateTemplate(settings.widgetTitleTemplate, jaql.column);
            } else {
                widgetTitle = settings.widgetTitle ? settings.widgetTitle : jaql.column;
            }

            return widgetTitle;

        }

        prism.registerSwitchDimension = function (options) {

            dimSettings[options.widget.oid] = {
                dimensions: options.dimensions,
                maxItemsBeforeSubMenuIsCreated: options.maxItemsBeforeSubMenuIsCreated ? options.maxItemsBeforeSubMenuIsCreated : maxItemsBeforeSubMenuIsCreatedDefault
            };
            $bindOnce(prism, "beforemenu", onBeforeMenu);
        };
    }]);
